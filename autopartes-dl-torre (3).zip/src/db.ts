/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Provider {
  id: string;
  name: string;
  phone: string;
}

export interface Part {
  id: string;
  name: string;
  side: string;
  position: string;
  height: string;
  prices: Record<string, number>; // providerId -> price
  salePrice?: number; // precioCliente (venta)
  isHunting?: boolean;
}

export interface QuoteItem {
  nombrePieza: string;
  costo: number;
  precioCliente: number;
}

export interface Quote {
  id: string;
  quoteNumber: string;
  clientName: string;
  whatsapp: string;
  sameNumber: boolean;
  phone: string;
  location: string;
  brand: string;
  model: string;
  year: string;
  version: string;
  notes: string;
  isUrgent: boolean;
  parts: Part[];
  items?: QuoteItem[]; 
  providers: Provider[];
  createdAt: number;
  status: 'pendiente' | 'vendido' | 'no_vendido';
  images: string[];
  isNotified?: boolean;
  isHunting?: boolean;
}

/**
 * Gets the timestamp for the start of the current week (Monday)
 */
export function getStartOfWeek(): number {
  const now = new Date();
  const day = now.getDay(); 
  const diff = now.getDate() - (day === 0 ? 6 : day - 1); 
  const start = new Date(now.setDate(diff));
  start.setHours(0, 0, 0, 0);
  return start.getTime();
}

/**
 * Automatically archives quotes older than the current week that are still 'pendiente'
 * MODIFIED: Now only handles manual transitions or can be triggered for specific logic.
 * The prompt requested: "Una cotización solo se mueve al Historial si el usuario cambia manualmente su estado a 'Vendido' o 'No Vendido'."
 * So we will disable the automatic background archiving in App.tsx but keep the helper if needed.
 */
export async function autoArchiveQuotes(): Promise<void> {
  // We will leave this existing function but it won't be called automatically in App.tsx anymore 
  // to respect the "Pendientes remain pending regardless of date" rule.
  return Promise.resolve();
}

export interface AppConfig {
  logo?: string;
  isDarkMode: boolean;
  businessPhone: string;
  weeklyMessage: string;
}

const DB_NAME = 'autopartes-db';
const DB_VERSION = 1;
const QUOTES_STORE = 'quotes';
const CONFIG_STORE = 'config';
const PROVIDERS_STORE = 'providers';

let db: IDBDatabase | null = null;

/**
 * Initializes the IndexedDB database
 */
export async function initDB(): Promise<void> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION + 1); // Increment version to add store

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(QUOTES_STORE)) {
        db.createObjectStore(QUOTES_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(CONFIG_STORE)) {
        db.createObjectStore(CONFIG_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(PROVIDERS_STORE)) {
        db.createObjectStore(PROVIDERS_STORE, { keyPath: 'id' });
      }
    };

    request.onsuccess = (event) => {
      db = (event.target as IDBOpenDBRequest).result;
      resolve();
    };

    request.onerror = (event) => {
      reject((event.target as IDBOpenDBRequest).error);
    };
  });
}

/**
 * Gets all quotes from the database
 */
export async function getQuotes(): Promise<Quote[]> {
  if (!db) await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction(QUOTES_STORE, 'readonly');
    const store = transaction.objectStore(QUOTES_STORE);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Saves a quote to the database
 */
export async function saveQuote(quote: Quote): Promise<void> {
  if (!db) await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction(QUOTES_STORE, 'readwrite');
    const store = transaction.objectStore(QUOTES_STORE);
    const request = store.put(quote);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Deletes a quote from the database
 */
export async function deleteQuote(id: string): Promise<void> {
  if (!db) await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction(QUOTES_STORE, 'readwrite');
    const store = transaction.objectStore(QUOTES_STORE);
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Gets the application configuration
 */
export async function getConfig(): Promise<AppConfig> {
  if (!db) await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction(CONFIG_STORE, 'readonly');
    const store = transaction.objectStore(CONFIG_STORE);
    const request = store.get('main');

    request.onsuccess = () => {
      const defaultConfig: AppConfig = {
        isDarkMode: false,
        businessPhone: '',
        weeklyMessage: '¡Gracias por su preferencia! Autopartes DLTorre.'
      };
      resolve(request.result || defaultConfig);
    };
    request.onerror = () => reject(request.error);
  });
}

/**
 * Gets all global providers
 */
export async function getProviders(): Promise<Provider[]> {
  if (!db) await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction(PROVIDERS_STORE, 'readonly');
    const store = transaction.objectStore(PROVIDERS_STORE);
    const request = store.getAll();

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Saves a global provider
 */
export async function saveProvider(provider: Provider): Promise<void> {
  if (!db) await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction(PROVIDERS_STORE, 'readwrite');
    const store = transaction.objectStore(PROVIDERS_STORE);
    const request = store.put(provider);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Deletes a global provider
 */
export async function deleteProvider(id: string): Promise<void> {
  if (!db) await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction(PROVIDERS_STORE, 'readwrite');
    const store = transaction.objectStore(PROVIDERS_STORE);
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Saves the application configuration
 */
export async function saveConfig(config: AppConfig): Promise<void> {
  if (!db) await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db!.transaction(CONFIG_STORE, 'readwrite');
    const store = transaction.objectStore(CONFIG_STORE);
    const request = store.put({ ...config, id: 'main' });

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}
