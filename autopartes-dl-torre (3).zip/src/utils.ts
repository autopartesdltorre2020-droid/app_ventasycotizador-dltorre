import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Utility to merge tailwind classes safely
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Formats a message for WhatsApp and returns the wa.me link
 */
export function formatWhatsApp(phone: string, message: string): string {
  // Remove non-numeric characters from phone
  const cleanPhone = phone.replace(/\D/g, '');
  const encodedMessage = encodeURIComponent(message);
  return `https://wa.me/${cleanPhone}?text=${encodedMessage}`;
}

/**
 * Generates a quote number based on the count
 * Format: COT-YYYY-000
 */
export function generateQuoteNumber(count: number): string {
  const year = new Date().getFullYear();
  const paddedCount = count.toString().padStart(3, '0');
  return `COT-${year}-${paddedCount}`;
}
