import React, { useState, useEffect } from 'react';
import { 
  PlusCircle, 
  ChevronLeft, 
  Moon,
  Sun
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  initDB, 
  getQuotes, 
  saveQuote, 
  getConfig, 
  saveConfig, 
  deleteQuote,
  getStartOfWeek,
  autoArchiveQuotes,
  getProviders,
  Quote, 
  AppConfig
} from './db';
import { cn } from './utils';

// Components
import Dashboard from './components/Dashboard';
import QuoteForm, { QuickPart, CarBrand } from './components/QuoteForm';
import PendingQuotes from './components/PendingQuotes';
import QuoteHistory from './components/QuoteHistory';
import CostMatrix from './components/CostMatrix';
import Stats from './components/Stats';
import ConfigView from './components/ConfigView';
import WeeklyMessage from './components/WeeklyMessage';
import ProviderManager from './components/ProviderManager';
import { Download, AlertTriangle, FileText, X as CloseIcon } from 'lucide-react';

type View = 'dashboard' | 'generate' | 'pending' | 'history' | 'stats' | 'config' | 'matrix' | 'weekly' | 'providers';

export default function App() {
  const [view, setView] = useState<View>('dashboard');
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [showAllQuotes, setShowAllQuotes] = useState(false);
  const [showBackupReminder, setShowBackupReminder] = useState(false);
  const [config, setConfig] = useState<AppConfig | null>(null);
  const [quickParts, setQuickParts] = useState<QuickPart[]>([]);
  const [carBrands, setCarBrands] = useState<CarBrand[]>([]);
  const [selectedQuote, setSelectedQuote] = useState<Quote | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [lastScrollPos, setLastScrollPos] = useState<Record<string, number>>({});
  const [previousView, setPreviousView] = useState<View>('dashboard');

  // Load initial data
  useEffect(() => {
    const loadData = async () => {
      try {
        await initDB();
        
        const [loadedQuotes, loadedConfig, loadedProviders] = await Promise.all([
          getQuotes(),
          getConfig(),
          getProviders()
        ]);

        // Resilient mapping: if status is missing, default to 'pendiente'
        // NEW RULE: All pending remain pending regardless of date.
        const resilientQuotes = loadedQuotes.map(q => ({
          ...q,
          status: q.status || 'pendiente'
        }));

        const startOfWeek = getStartOfWeek();
        
        // Initial set based on view logic will be handled inside components
        // but we store the full resilient list in state
        setQuotes(resilientQuotes);
        setShowAllQuotes(false); // Used for history lazy loading
        
        setConfig(loadedConfig);
        setIsDarkMode(loadedConfig.isDarkMode);

        // Check for backup reminder once per day
        const lastReminder = localStorage.getItem('lastBackupReminder');
        const today = new Date().toDateString();
        if (lastReminder !== today) {
          setShowBackupReminder(true);
        }

        // Load Quick Parts from localStorage
        const storedQuickParts = localStorage.getItem('quickParts');
        if (storedQuickParts) {
          setQuickParts(JSON.parse(storedQuickParts));
        } else {
          const defaultQuickParts: QuickPart[] = [
            { nombre: "Fascia", lado: "N/A", posicion: "Delantero", altura: "N/A" },
            { nombre: "Cofre", lado: "N/A", posicion: "N/A", altura: "N/A" },
            { nombre: "Faro", lado: "Derecho", posicion: "Delantero", altura: "N/A" },
            { nombre: "Faro", lado: "Izquierdo", posicion: "Delantero", altura: "N/A" },
            { nombre: "Salpicadera", lado: "Derecho", posicion: "Delantero", altura: "N/A" },
            { nombre: "Salpicadera", lado: "Izquierdo", posicion: "Delantero", altura: "N/A" }
          ];
          localStorage.setItem('quickParts', JSON.stringify(defaultQuickParts));
          setQuickParts(defaultQuickParts);
        }

        // Load Car Brands from localStorage
        const storedCarBrands = localStorage.getItem('carBrands');
        if (storedCarBrands) {
          setCarBrands(JSON.parse(storedCarBrands));
        } else {
          const defaultCarBrands: CarBrand[] = [
            { marca: "Toyota", modelos: ["Hilux", "Tacoma", "Corolla", "Yaris"] },
            { marca: "Nissan", modelos: ["NP300", "Sentra", "Versa", "March"] },
            { marca: "Chevrolet", modelos: ["Aveo", "Spark", "Silverado", "Onix"] },
            { marca: "Ford", modelos: ["Ranger", "F-150", "Figo", "EcoSport"] }
          ];
          localStorage.setItem('carBrands', JSON.stringify(defaultCarBrands));
          setCarBrands(defaultCarBrands);
        }
      } catch (error) {
        console.error("Error loading initial data:", error);
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  const handleSaveQuickParts = (newParts: QuickPart[]) => {
    setQuickParts(newParts);
    localStorage.setItem('quickParts', JSON.stringify(newParts));
  };

  const handleSaveCarBrands = (newBrands: CarBrand[]) => {
    setCarBrands(newBrands);
    localStorage.setItem('carBrands', JSON.stringify(newBrands));
  };

  const handleNavigate = (newView: View) => {
    // Save current scroll position for the current view
    setLastScrollPos(prev => ({ ...prev, [view]: window.scrollY }));
    setPreviousView(view);
    setView(newView);
    // Reset scroll for new view (will be restored if it's a return)
    window.scrollTo(0, 0);
  };

  // Restore scroll position when view changes
  useEffect(() => {
    if (lastScrollPos[view] !== undefined) {
      // Use requestAnimationFrame for smoother and more reliable restoration
      const restoreScroll = () => {
        window.scrollTo({
          top: lastScrollPos[view],
          behavior: 'instant'
        });
      };

      // Try immediately and with a small delay to handle dynamic content
      requestAnimationFrame(restoreScroll);
      const timer = setTimeout(restoreScroll, 100);
      return () => clearTimeout(timer);
    }
  }, [view]);

  // Sync dark mode
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const handleSaveConfig = async (newConfig: AppConfig) => {
    setConfig(newConfig);
    setIsDarkMode(newConfig.isDarkMode);
    await saveConfig(newConfig);
  };

  const handleSaveQuoteToDB = async (quote: Quote) => {
    await saveQuote(quote);
    const updatedQuotes = await getQuotes();
    setQuotes(updatedQuotes);
  };

  const handleCloseQuote = async (id: string, status: 'vendido' | 'no_vendido' = 'vendido') => {
    const quote = quotes.find(q => q.id === id);
    if (quote) {
      // Preserve all fields and update status while ensuring other data stays intact
      const updatedQuote = { ...quote, status };
      await saveQuote(updatedQuote);
      const updatedQuotes = await getQuotes();
      
      // Update local state resiliently
      setQuotes(updatedQuotes.map(q => ({
        ...q,
        status: q.status || 'no_vendido' // Resilient fallback
      })));
    }
  };

  const handleReactivateQuote = async (id: string) => {
    const quote = quotes.find(q => q.id === id);
    if (quote) {
      const updatedQuote = { ...quote, status: 'pendiente' as const };
      await saveQuote(updatedQuote);
      const updatedQuotes = await getQuotes();
      setQuotes(updatedQuotes);
    }
  };

  const handleDeleteQuote = async (id: string) => {
    if (confirm('¿Estás seguro de eliminar esta cotización?')) {
      await deleteQuote(id);
      const updatedQuotes = await getQuotes();
      setQuotes(updatedQuotes);
    }
  };

  const handleToggleNotified = async (id: string, value: boolean) => {
    const quote = quotes.find(q => q.id === id);
    if (quote) {
      const updatedQuote = { ...quote, isNotified: value };
      await saveQuote(updatedQuote);
      const updatedQuotes = await getQuotes();
      setQuotes(updatedQuotes);
    }
  };

  const handleToggleHunting = async (id: string, value: boolean) => {
    const quote = quotes.find(q => q.id === id);
    if (quote) {
      const updatedQuote = { ...quote, isHunting: value };
      await saveQuote(updatedQuote);
      const updatedQuotes = await getQuotes();
      setQuotes(updatedQuotes);
    }
  };

  const handleLoadAllQuotes = async () => {
    setIsLoading(true);
    try {
      const allQuotes = await getQuotes();
      setQuotes(allQuotes);
      setShowAllQuotes(true);
    } catch (error) {
      console.error("Error loading all quotes:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Scheduled Backup and Data Sync
  useEffect(() => {
    const checkScheduledBackup = () => {
      const now = new Date();
      const day = now.getDay(); // 0: Sun, 1: Mon...
      const hour = now.getHours();
      const minute = now.getMinutes();
      
      const lastScheduled = localStorage.getItem('lastScheduledBackup');
      const todayKey = now.toDateString();

      // Check if already reminded today via schedule
      if (lastScheduled === todayKey) return;

      // Lunes a Viernes: 17:30 (5:30 PM) en adelante
      if (day >= 1 && day <= 5) {
        if (hour > 17 || (hour === 17 && minute >= 30)) {
          setShowBackupReminder(true);
          localStorage.setItem('lastScheduledBackup', todayKey);
        }
      } 
      // Sábados: 13:00 (1:00 PM) en adelante
      else if (day === 6) {
        if (hour >= 13) {
          setShowBackupReminder(true);
          localStorage.setItem('lastScheduledBackup', todayKey);
        }
      }
    };

    const timer = setInterval(checkScheduledBackup, 60000); // Check every minute
    return () => clearInterval(timer);
  }, []);

  const handleDownloadBackup = async (format: 'json' | 'csv' = 'json') => {
    const date = new Date().toISOString().split('T')[0];
    const providers = await getProviders();
    let dataBlob: Blob;
    let fileName = "";

    if (format === 'json') {
      // Universal JSON: Quotes + Providers
      const fullBackup = {
        version: "2.0",
        exportDate: new Date().toISOString(),
        quotes: quotes,
        providers: providers
      };
      dataBlob = new Blob([JSON.stringify(fullBackup, null, 2)], { type: "application/json" });
      fileName = `Autopartes_DL_Torre_Universal_${date}.json`;
    } else {
      // Professional CSV with UTF-8 BOM for Excel
      const headers = ["Fecha", "Folio", "Cliente", "Auto", "Refaccion", "Proveedor", "Costo", "Estado"];
      const rows: string[][] = [];
      
      quotes.forEach(q => {
        q.parts.forEach(p => {
          rows.push([
            new Date(q.createdAt).toLocaleDateString(),
            q.id.substring(0, 8),
            q.clientName || 'N/A',
            `${q.carBrand} ${q.carModel}`,
            p.name,
            p.providerName || 'Pendiente',
            (p.bestPrice || 0).toString(),
            q.status === 'vendido' ? 'VENDIDO' : q.status === 'no_vendido' ? 'NO VENDIDO' : 'PENDIENTE'
          ]);
        });
      });

      const csvContent = [headers.join(','), ...rows.map(r => r.map(c => `"${c.replace(/"/g, '""')}"`).join(','))].join('\n');
      // Adding UTF-8 BOM (Byte Order Mark) for Excel compatibility
      const BOM = new Uint8Array([0xEF, 0xBB, 0xBF]);
      dataBlob = new Blob([BOM, csvContent], { type: "text/csv;charset=utf-8" });
      fileName = `Reporte_Ventas_Autopartes_${date}.csv`;
    }

    const url = URL.createObjectURL(dataBlob);
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", url);
    downloadAnchorNode.setAttribute("download", fileName);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
    URL.revokeObjectURL(url);
    
    localStorage.setItem('lastBackupReminder', new Date().toDateString());
    setShowBackupReminder(false);
  };

  const handleDismissBackup = () => {
    localStorage.setItem('lastBackupReminder', new Date().toDateString());
    setShowBackupReminder(false);
  };

  if (isLoading || !config) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8f9fa] dark:bg-[#121212]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#0A3D62]"></div>
      </div>
    );
  }

  return (
    <div className={cn(
      "min-h-screen transition-colors duration-300",
      "bg-[#f8f9fa] text-[#1a1a1a]",
      "dark:bg-[#121212] dark:text-white"
    )}>
      <header className="bg-[#0A3D62] text-white p-4 sticky top-0 z-50 shadow-lg flex justify-between items-center overflow-hidden">
        {/* Racetrack Accent */}
        <div className="absolute top-0 left-0 w-full h-[3px] bg-[repeating-linear-gradient(90deg,#fff,#fff_10px,#000_10px,#000_20px)] opacity-30"></div>
        
        <div className="flex items-center gap-3 cursor-pointer relative z-10" onClick={() => handleNavigate('dashboard')}>
          {config?.logo ? (
            <img src={config.logo} alt="Logo" className="max-h-[40px] w-auto rounded" />
          ) : (
            <div className="bg-white p-1.5 rounded-lg">
              <PlusCircle className="text-[#0A3D62] w-6 h-6" />
            </div>
          )}
          <h1 className="text-xl font-bold tracking-tight">AUTOPARTES DL TORRE</h1>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={() => handleSaveConfig({ ...config, isDarkMode: !isDarkMode })}
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
          >
            {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
          {view !== 'dashboard' && (
            <button 
              onClick={() => handleNavigate(previousView)}
              className="bg-white/10 hover:bg-white/20 px-4 py-1.5 rounded-full text-sm font-medium flex items-center gap-2 transition-all"
            >
              <ChevronLeft className="w-4 h-4" /> Volver
            </button>
          )}
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 md:p-6">
        <AnimatePresence mode="wait">
          {view === 'dashboard' && (
            <Dashboard 
              setView={handleNavigate} 
              pendingCount={quotes.filter(q => q.status === 'pendiente').length} 
            />
          )}
          {view === 'generate' && (
            <QuoteForm 
              config={config} 
              quickParts={quickParts}
              carBrands={carBrands}
              onSave={handleSaveQuoteToDB} 
              onBack={() => handleNavigate('dashboard')} 
              quotesCount={quotes.length}
            />
          )}
          {view === 'pending' && (
            <PendingQuotes 
              quotes={quotes.filter(q => q.status === 'pendiente')} 
              onSelect={(q) => { setSelectedQuote(q); handleNavigate('matrix'); }}
              onDelete={handleDeleteQuote}
              onClose={handleCloseQuote}
              onToggleNotified={handleToggleNotified}
              onToggleHunting={handleToggleHunting}
            />
          )}
          {view === 'history' && (() => {
            const historyQuotes = quotes.filter(q => q.status !== 'pendiente');
            const startOfWeek = getStartOfWeek();
            const filteredHistory = showAllQuotes 
              ? historyQuotes 
              : historyQuotes.filter(q => q.createdAt >= startOfWeek);
            const hasMoreHistory = historyQuotes.length > filteredHistory.length;

            return (
              <QuoteHistory 
                quotes={filteredHistory} 
                onSelect={(q) => { setSelectedQuote(q); handleNavigate('matrix'); }}
                onDelete={handleDeleteQuote}
                onReactivate={handleReactivateQuote}
                showAllButton={hasMoreHistory}
                onLoadAll={handleLoadAllQuotes}
              />
            );
          })()}
          {view === 'matrix' && selectedQuote && (
            <CostMatrix 
              quote={selectedQuote} 
              config={config} 
              onSave={handleSaveQuoteToDB}
              onBack={() => handleNavigate(previousView)}
            />
          )}
          {view === 'stats' && (
            <Stats quotes={quotes} />
          )}
          {view === 'config' && (
            <ConfigView 
              config={config} 
              quickParts={quickParts}
              carBrands={carBrands}
              onSave={handleSaveConfig} 
              onSaveQuickParts={handleSaveQuickParts}
              onSaveCarBrands={handleSaveCarBrands}
              quotes={quotes} 
            />
          )}
          {view === 'weekly' && (
            <WeeklyMessage config={config} onSave={handleSaveConfig} />
          )}
          {view === 'providers' && (
            <ProviderManager onBack={() => handleNavigate('dashboard')} />
          )}
        </AnimatePresence>
      </main>

      {/* Backup Reminder Modal */}
      <AnimatePresence>
        {showBackupReminder && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white dark:bg-[#1e1e1e] rounded-3xl shadow-2xl max-w-md w-full p-8 border-t-4 border-[#0A3D62] relative overflow-hidden"
            >
              <button 
                onClick={handleDismissBackup}
                className="absolute top-4 right-4 p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors"
              >
                <CloseIcon className="w-5 h-5 text-gray-400" />
              </button>

              <div className="flex flex-col items-center text-center space-y-6">
                <div className="w-20 h-20 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                  <AlertTriangle className="w-10 h-10 text-[#0A3D62] dark:text-blue-400" />
                </div>
                
                <div className="space-y-2">
                  <h2 className="text-2xl font-black text-[#0A3D62] dark:text-blue-400 uppercase tracking-tight">¡Seguridad primero!</h2>
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed font-medium">
                    Recuerda realizar tu respaldo diario de <span className="text-[#0A3D62] dark:text-blue-400 font-bold">Autopartes DL Torre</span> para proteger tus datos.
                  </p>
                </div>

                <div className="flex flex-col gap-3 w-full">
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => handleDownloadBackup('json')}
                      className="min-h-[50px] bg-[#0A3D62] hover:bg-blue-700 text-white rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-blue-900/20"
                    >
                      <Download className="w-4 h-4" /> JSON
                    </button>
                    <button
                      onClick={() => handleDownloadBackup('csv')}
                      className="min-h-[50px] bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-emerald-900/20"
                    >
                      <FileText className="w-4 h-4" /> EXCEL
                    </button>
                  </div>
                  <button
                    onClick={handleDismissBackup}
                    className="min-h-[50px] bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-2xl font-bold transition-all"
                  >
                    Quizás luego
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
