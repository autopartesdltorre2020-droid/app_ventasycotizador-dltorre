import React, { useState, useMemo } from 'react';
import { 
  History, 
  Trash2, 
  Clock,
  Phone,
  Car,
  User,
  Hash,
  ChevronDown,
  ChevronUp,
  DollarSign
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';
import { Quote } from '../db';
import { cn, formatWhatsApp } from '../utils';
import SearchHeader from './SearchHeader';

interface QuoteHistoryProps {
  quotes: Quote[];
  onSelect: (q: Quote) => void;
  onDelete: (id: string) => void;
  onReactivate: (id: string) => void;
  showAllButton?: boolean;
  onLoadAll?: () => void;
}

export default function QuoteHistory({ 
  quotes, 
  onSelect, 
  onDelete, 
  onReactivate,
  showAllButton,
  onLoadAll
}: QuoteHistoryProps) {
  const [search, setSearch] = useState('');
  const [showPriceIntelligence, setShowPriceIntelligence] = useState(true);

  // Intelligent Search Logic
  const filteredQuotes = useMemo(() => {
    if (!search) return quotes.sort((a, b) => b.createdAt - a.createdAt);

    const term = search.toLowerCase().trim();
    const isFolioSearch = term.startsWith('cot-') || /^\d{1,4}$/.test(term);
    const isWhatsAppSearch = /^\d{5,}$/.test(term.replace(/\D/g, ''));

    return quotes.filter(q => {
      if (isFolioSearch) return q.quoteNumber.toLowerCase().includes(term);
      if (isWhatsAppSearch) return q.whatsapp.replace(/\D/g, '').includes(term.replace(/\D/g, ''));
      return (
        q.brand.toLowerCase().includes(term) ||
        q.model.toLowerCase().includes(term) ||
        q.clientName.toLowerCase().includes(term) ||
        q.location.toLowerCase().includes(term)
      );
    }).sort((a, b) => b.createdAt - a.createdAt);
  }, [quotes, search]);

  // Price Intelligence Logic
  const priceIntelligence = useMemo(() => {
    if (!search || filteredQuotes.length === 0) return null;
    const term = search.toLowerCase().trim();
    const isVehicleSearch = filteredQuotes.some(q => 
      q.brand.toLowerCase().includes(term) || q.model.toLowerCase().includes(term)
    );
    if (!isVehicleSearch) return null;

    const partsMap: Record<string, { 
      name: string, 
      prices: { provider: string, price: number, date: number, quoteNum: string }[] 
    }> = {};

    filteredQuotes.forEach(q => {
      q.parts.forEach(p => {
        const side = p.side !== 'N/A' ? p.side : '';
        const pos = p.position !== 'N/A' ? p.position : '';
        const alt = p.height !== 'N/A' ? p.height : '';
        const fullName = `${p.name} ${side} ${pos} ${alt}`.replace(/\s+/g, ' ').trim();
        if (!partsMap[fullName]) partsMap[fullName] = { name: fullName, prices: [] };

        Object.entries(p.prices).forEach(([provId, price]) => {
          const numPrice = price as number;
          if (numPrice > 0) {
            const provider = q.providers.find(prov => prov.id === provId);
            partsMap[fullName].prices.push({
              provider: provider?.name || 'Desconocido',
              price: numPrice,
              date: q.createdAt,
              quoteNum: q.quoteNumber
            });
          }
        });
      });
    });

    Object.values(partsMap).forEach(p => p.prices.sort((a, b) => b.date - a.date));
    return Object.values(partsMap).filter(p => p.prices.length > 0);
  }, [filteredQuotes, search]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
      <SearchHeader 
        search={search}
        setSearch={setSearch}
        placeholder="Folio (COT-...), WhatsApp o Modelo de Auto..."
        count={filteredQuotes.length}
        title="Histórico de Cotizaciones"
        icon={<History className="text-slate-500" />}
      />

      {/* PRICE INTELLIGENCE SECTION */}
      <AnimatePresence>
        {priceIntelligence && priceIntelligence.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl border border-indigo-100 dark:border-indigo-800 overflow-hidden mb-6"
          >
            <div 
              className="p-4 flex justify-between items-center cursor-pointer hover:bg-indigo-100/50 dark:hover:bg-indigo-800/30 transition-colors"
              onClick={() => setShowPriceIntelligence(!showPriceIntelligence)}
            >
              <div className="flex items-center gap-2 text-indigo-700 dark:text-indigo-400 font-bold">
                <DollarSign className="w-5 h-5" />
                <span>INTELIGENCIA DE PRECIOS: {search.toUpperCase()}</span>
              </div>
              {showPriceIntelligence ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
            </div>
            
            {showPriceIntelligence && (
              <div className="p-4 pt-0 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {priceIntelligence.map((part, i) => (
                  <div key={i} className="bg-white dark:bg-[#1e1e1e] p-3 rounded-xl shadow-sm border dark:border-gray-800">
                    <h4 className="font-bold text-sm mb-2 text-[#0A3D62] dark:text-blue-400">{part.name}</h4>
                    <div className="space-y-2">
                      {part.prices.slice(0, 3).map((p, j) => (
                        <div key={j} className="flex justify-between items-center text-xs">
                          <div className="flex flex-col">
                            <span className="font-medium text-gray-600 dark:text-gray-300">{p.provider}</span>
                            <span className="text-[10px] text-gray-400">{format(p.date, 'dd/MM/yy')} • {p.quoteNum}</span>
                          </div>
                          <span className="font-black text-emerald-600 dark:text-emerald-400 text-sm">${p.price}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* RESULTS TABLE */}
      <div className="bg-white dark:bg-[#1e1e1e] rounded-2xl shadow-xl overflow-hidden border dark:border-gray-800">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-gray-50 dark:bg-gray-800/50 text-xs font-bold text-gray-500 uppercase">
              <tr>
                <th className="p-4">Folio</th>
                <th className="p-4">Fecha</th>
                <th className="p-4">Vehículo</th>
                <th className="p-4">Cliente</th>
                <th className="p-4">Estado</th>
                <th className="p-4 text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y dark:divide-gray-800">
              {filteredQuotes.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-20 text-center">
                    <div className="flex flex-col items-center gap-3 text-gray-400">
                      <SearchHeader search={search} setSearch={setSearch} count={0} title="" icon={null} />
                      <p className="font-bold">No se encontraron resultados para "{search}"</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredQuotes.map(quote => (
                  <tr 
                    key={quote.id} 
                    className={cn(
                      "hover:bg-gray-50 dark:hover:bg-gray-800/30 transition-colors cursor-pointer group",
                      quote.status === 'vendido' ? "bg-emerald-50/40 dark:bg-emerald-900/10" : "bg-gray-50/40 dark:bg-gray-800/20"
                    )} 
                    onClick={() => onSelect(quote)}
                  >
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <Hash className="w-3 h-3 text-gray-300" />
                        <span className="font-mono text-sm font-bold text-[#0A3D62] dark:text-blue-400">{quote.quoteNumber}</span>
                      </div>
                    </td>
                    <td className="p-4 text-sm text-gray-500">{format(quote.createdAt, 'dd/MM/yyyy')}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <Car className="w-4 h-4 text-gray-300" />
                        <div>
                          <div className="font-bold">{quote.brand} {quote.model}</div>
                          <div className="text-xs text-gray-400">{quote.year}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-gray-300" />
                        <div>
                          <div className="text-sm font-medium">{quote.clientName}</div>
                          <a 
                            href={formatWhatsApp(quote.whatsapp, '')} 
                            target="_blank" 
                            onClick={(e) => e.stopPropagation()}
                            className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 hover:underline"
                          >
                            <Phone className="w-3 h-3" /> {quote.whatsapp}
                          </a>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className={cn(
                        "text-[10px] font-bold px-2 py-1 rounded-full uppercase",
                        quote.status === 'vendido' 
                          ? "bg-emerald-100 text-emerald-700 border border-emerald-200" 
                          : "bg-gray-100 text-gray-600 border border-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700"
                      )}>
                        {quote.status === 'vendido' ? 'Vendido' : 'No Vendido'}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <div className="flex justify-end gap-1">
                        <button 
                          onClick={(e) => { e.stopPropagation(); onDelete(quote.id); }}
                          className="p-2 text-red-500/70 hover:text-red-600 bg-red-50 dark:bg-red-900/20 rounded-lg transition-all"
                          title="Eliminar"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={(e) => { e.stopPropagation(); onReactivate(quote.id); }}
                          className="p-2 text-amber-600 dark:text-amber-400 hover:text-amber-700 bg-amber-50 dark:bg-amber-900/20 rounded-lg transition-all"
                          title="Reactivar Cotización"
                        >
                          <Clock className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
      {showAllButton && (
        <div className="flex justify-center mt-6">
          <button 
            onClick={onLoadAll}
            className="bg-white dark:bg-gray-800 text-[#0A3D62] dark:text-blue-400 px-6 py-2.5 rounded-xl font-bold text-sm border-2 border-dashed border-blue-200 dark:border-blue-900/40 hover:bg-blue-50 dark:hover:bg-blue-900/10 transition-all flex items-center gap-2 uppercase tracking-tight"
          >
            <Clock className="w-4 h-4" /> Cargar resto de cotizaciones (Historial Completo)
          </button>
        </div>
      )}
    </motion.div>
  );
}
