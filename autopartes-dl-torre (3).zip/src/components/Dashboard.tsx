import React, { useState } from 'react';
import { 
  PlusCircle, 
  Clock, 
  History, 
  Settings, 
  BarChart3, 
  Send, 
  AlertCircle,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../utils';

type View = 'dashboard' | 'generate' | 'pending' | 'history' | 'stats' | 'config' | 'matrix' | 'weekly' | 'providers';

interface DashboardProps {
  setView: (v: View) => void;
  pendingCount: number;
}

export default function Dashboard({ setView, pendingCount }: DashboardProps) {
  const [showHelp, setShowHelp] = useState(false);

  const menuItems = [
    { id: 'generate', label: 'Generar Cotización', icon: PlusCircle, color: 'bg-blue-600', desc: 'Crear nuevo pedido' },
    { id: 'pending', label: 'Pendientes', icon: Clock, color: 'bg-amber-500', desc: `${pendingCount} por completar`, badge: pendingCount },
    { id: 'history', label: 'Histórico', icon: History, color: 'bg-slate-600', desc: 'Ver cotizaciones pasadas' },
    { id: 'providers', label: 'Proveedores', icon: Users, color: 'bg-[#0A3D62]', desc: 'Directorio de contactos' },
    { id: 'weekly', label: 'Mensaje Semanal', icon: Send, color: 'bg-indigo-600', desc: 'Configurar texto WhatsApp' },
    { id: 'stats', label: 'Estadísticas', icon: BarChart3, color: 'bg-emerald-600', desc: 'Rendimiento del negocio' },
    { id: 'config', label: 'Configuración', icon: Settings, color: 'bg-gray-700', desc: 'Marcas, modelos y más' },
  ];

  return (
    <div className="space-y-8">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as View)}
            className={cn(
              "relative group p-6 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 text-left overflow-hidden",
              "bg-white dark:bg-[#1e1e1e] border border-gray-100 dark:border-gray-800",
              "flex flex-col gap-4"
            )}
          >
            <div className={cn("w-14 h-14 rounded-xl flex items-center justify-center text-white shadow-lg", item.color)}>
              <item.icon className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-xl font-bold dark:text-white">{item.label}</h3>
              <p className="text-gray-500 dark:text-gray-400 text-sm">{item.desc}</p>
            </div>
            {item.badge !== undefined && item.badge > 0 && (
              <div className="absolute top-4 right-4 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full animate-pulse">
                {item.badge}
              </div>
            )}
            <div className="absolute bottom-0 right-0 p-2 opacity-5 group-hover:opacity-10 transition-opacity">
              <item.icon className="w-24 h-24 transform translate-x-4 translate-y-4" />
            </div>
          </button>
        ))}
      </motion.div>

      <div className="flex justify-center">
        <button 
          onClick={() => setShowHelp(true)}
          className="text-gray-400 hover:text-[#0A3D62] transition-colors flex items-center gap-2 text-sm font-bold"
        >
          <AlertCircle className="w-4 h-4" /> GUÍA RÁPIDA DE USO
        </button>
      </div>

      <AnimatePresence>
        {showHelp && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setShowHelp(false)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white dark:bg-[#1e1e1e] p-8 rounded-3xl max-w-lg w-full shadow-2xl space-y-6"
              onClick={e => e.stopPropagation()}
            >
              <h3 className="text-2xl font-bold text-[#0A3D62] dark:text-blue-400">Guía Autopartes Pro</h3>
              <ul className="space-y-4 text-sm">
                <li className="flex gap-3">
                  <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-full flex items-center justify-center font-bold shrink-0">1</div>
                  <p><b>Generar:</b> Crea la cotización y envía el resumen por WhatsApp al cliente automáticamente.</p>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-full flex items-center justify-center font-bold shrink-0">2</div>
                  <p><b>Cacería:</b> En la matriz de costos, usa el "Modo Cacería" para copiar la lista limpia y enviarla a tus proveedores.</p>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-full flex items-center justify-center font-bold shrink-0">3</div>
                  <p><b>Matriz:</b> Ingresa los precios de cada proveedor. El sistema resaltará automáticamente el <b>precio más bajo</b> en verde.</p>
                </li>
                <li className="flex gap-3">
                  <div className="w-6 h-6 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-full flex items-center justify-center font-bold shrink-0">4</div>
                  <p><b>Offline:</b> Todo se guarda en tu dispositivo. No necesitas internet para trabajar, solo para enviar mensajes.</p>
                </li>
              </ul>
              <button 
                onClick={() => setShowHelp(false)}
                className="w-full bg-[#0A3D62] text-white py-3 rounded-xl font-bold"
              >
                ENTENDIDO
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
