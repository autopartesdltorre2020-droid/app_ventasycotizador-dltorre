import React, { useState } from 'react';
import { 
  Send 
} from 'lucide-react';
import { motion } from 'motion/react';
import { AppConfig } from '../db';

interface WeeklyMessageProps {
  config: AppConfig;
  onSave: (c: AppConfig) => void;
}

export default function WeeklyMessage({ config, onSave }: WeeklyMessageProps) {
  const [msg, setMsg] = useState(config.weeklyMessage);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-2xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold flex items-center gap-2">
        <Send className="text-indigo-500" /> Mensaje de la Semana
      </h2>
      <div className="bg-white dark:bg-[#1e1e1e] p-6 rounded-2xl shadow-xl border dark:border-gray-800">
        <p className="text-sm text-gray-500 mb-4">Este texto se incluirá al final de cada mensaje de WhatsApp enviado a los clientes.</p>
        <textarea 
          className="w-full p-4 rounded-xl border dark:bg-gray-800 dark:border-gray-700 h-40 mb-6 focus:ring-2 focus:ring-indigo-500 outline-none"
          value={msg}
          onChange={e => setMsg(e.target.value)}
          placeholder="Escribe aquí tu mensaje promocional o de agradecimiento..."
        />
        <button 
          onClick={() => {
            onSave({ ...config, weeklyMessage: msg });
            alert('Mensaje guardado');
          }}
          className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-indigo-700 transition-all"
        >
          ACTUALIZAR MENSAJE
        </button>
      </div>
    </motion.div>
  );
}
