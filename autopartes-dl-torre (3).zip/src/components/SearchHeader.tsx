import React, { useMemo } from 'react';
import { 
  Search, 
  Trash2, 
  Phone,
  Car,
  Hash
} from 'lucide-react';

interface SearchHeaderProps {
  search: string;
  setSearch: (s: string) => void;
  placeholder?: string;
  count: number;
  title: string;
  icon: React.ReactNode;
}

export default function SearchHeader({ 
  search, 
  setSearch, 
  placeholder = "Buscar...", 
  count, 
  title, 
  icon 
}: SearchHeaderProps) {
  const searchIcon = useMemo(() => {
    const term = search.toLowerCase().trim();
    if (!term) return <Search className="w-5 h-5 text-gray-400" />;
    if (term.startsWith('cot-') || /^\d{1,4}$/.test(term)) return <Hash className="w-5 h-5 text-blue-500" />;
    if (/^\d{5,}$/.test(term.replace(/\D/g, ''))) return <Phone className="w-5 h-5 text-emerald-500" />;
    return <Car className="w-5 h-5 text-indigo-500" />;
  }, [search]);

  return (
    <div className="flex flex-col gap-6 mb-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          {icon} {title}
        </h2>
        <span className="bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full text-xs font-bold text-gray-500">
          {count} TOTAL
        </span>
      </div>

      <div className="relative group">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 transition-transform group-focus-within:scale-110">
          {searchIcon}
        </div>
        <input 
          type="text" 
          placeholder={placeholder}
          className="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-transparent bg-white dark:bg-[#1e1e1e] shadow-lg outline-none focus:border-[#0A3D62] dark:focus:border-blue-500 transition-all text-lg font-medium"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        {search && (
          <button 
            onClick={() => setSearch('')}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-1 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"
          >
            <Trash2 className="w-4 h-4 text-gray-400" />
          </button>
        )}
      </div>
    </div>
  );
}
