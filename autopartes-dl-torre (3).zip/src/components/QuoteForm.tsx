import React, { useState, useMemo, useEffect } from 'react';
import { 
  Plus, 
  X, 
  Camera, 
  Send, 
  Save, 
  AlertCircle 
} from 'lucide-react';
import { motion } from 'motion/react';
import { Quote, AppConfig } from '../db';
import { cn, formatWhatsApp, generateQuoteNumber } from '../utils';

export interface QuickPart {
  nombre: string;
  lado: string;
  posicion: string;
  altura: string;
}

export interface CarBrand {
  marca: string;
  modelos: string[];
}

interface QuoteFormProps {
  config: AppConfig;
  quickParts: QuickPart[];
  carBrands: CarBrand[];
  onSave: (q: Quote) => void;
  onBack: () => void;
  quotesCount: number;
}

export default function QuoteForm({ 
  config, 
  quickParts, 
  carBrands, 
  onSave, 
  onBack, 
  quotesCount 
}: QuoteFormProps) {
  const [formData, setFormData] = useState({
    clientName: '',
    whatsapp: '',
    sameNumber: true,
    phone: '',
    location: '',
    brand: carBrands[0]?.marca || '',
    model: carBrands[0]?.modelos[0] || '',
    year: new Date().getFullYear().toString(),
    version: '',
    notes: '',
    isUrgent: false
  });

  const availableModels = useMemo(() => {
    const brand = carBrands.find(b => b.marca === formData.brand);
    return brand ? brand.modelos : [];
  }, [formData.brand, carBrands]);

  useEffect(() => {
    if (!availableModels.includes(formData.model)) {
      setFormData(prev => ({ ...prev, model: availableModels[0] || '' }));
    }
  }, [availableModels]);

  const [parts, setParts] = useState<{ name: string, side: string, position: string, height: string }[]>([
    { name: '', side: 'N/A', position: 'N/A', height: 'N/A' }
  ]);

  const [images, setImages] = useState<string[]>([]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files) as File[];
      files.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result;
          if (typeof result === 'string') {
            setImages(prev => [...prev, result]);
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const addPart = (name: string = '') => {
    setParts([...parts, { name, side: 'N/A', position: 'N/A', height: 'N/A' }]);
  };

  const removePart = (index: number) => {
    setParts(parts.filter((_, i) => i !== index));
  };

  const handleSubmit = (onlySave: boolean) => {
    if (!formData.clientName || !formData.whatsapp || !formData.location) {
      alert('Por favor rellena los campos obligatorios');
      return;
    }

    const newQuote: Quote = {
      id: crypto.randomUUID(),
      quoteNumber: generateQuoteNumber(quotesCount + 1),
      ...formData,
      parts: parts.map(p => ({ ...p, id: crypto.randomUUID(), prices: {} })),
      providers: [],
      createdAt: Date.now(),
      status: 'pendiente',
      images: images
    };

    onSave(newQuote);

    if (!onlySave) {
      const partsText = parts.map(p => `- ${p.name} ${p.side !== 'N/A' ? p.side : ''} ${p.position !== 'N/A' ? p.position : ''}`).join('\n');
      const message = `*COTIZACIÓN: ${newQuote.quoteNumber}*\n\n` +
        `*Cliente:* ${formData.clientName}\n` +
        `*Vehículo:* ${formData.brand} ${formData.model} ${formData.year}\n` +
        `*Población:* ${formData.location}\n\n` +
        `*Piezas:*\n${partsText}\n\n` +
        `${formData.notes ? `*Notas:* ${formData.notes}\n\n` : ''}` +
        `${config.weeklyMessage}`;
      
      window.open(formatWhatsApp(formData.whatsapp, message), '_blank');
    }

    onBack();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="bg-white dark:bg-[#1e1e1e] rounded-2xl shadow-xl p-6 max-w-4xl mx-auto"
    >
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold text-[#0A3D62] dark:text-blue-400">Nueva Cotización</h2>
        <div className="text-sm font-mono bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-lg">
          {generateQuoteNumber(quotesCount + 1)}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <section className="space-y-4">
          <h3 className="font-bold border-b pb-2 dark:border-gray-700">Datos del Cliente</h3>
          <div className="space-y-3">
            <div>
              <label className="text-xs font-bold uppercase text-gray-500">Nombre *</label>
              <input 
                type="text" 
                className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-[#0A3D62]"
                value={formData.clientName}
                onChange={e => setFormData({ ...formData, clientName: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold uppercase text-gray-500">WhatsApp *</label>
                <input 
                  type="tel" 
                  className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-[#0A3D62]"
                  value={formData.whatsapp}
                  onChange={e => setFormData({ ...formData, whatsapp: e.target.value })}
                />
              </div>
              <div>
                <label className="text-xs font-bold uppercase text-gray-500">Población *</label>
                <input 
                  type="text" 
                  className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-[#0A3D62]"
                  value={formData.location}
                  onChange={e => setFormData({ ...formData, location: e.target.value })}
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <input 
                type="checkbox" 
                id="sameNumber"
                checked={formData.sameNumber}
                onChange={e => setFormData({ ...formData, sameNumber: e.target.checked })}
                className="w-5 h-5 rounded"
              />
              <label htmlFor="sameNumber" className="text-sm">Mismo número para llamadas</label>
            </div>
            {!formData.sameNumber && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                <label className="text-xs font-bold uppercase text-gray-500">Teléfono Alternativo</label>
                <input 
                  type="tel" 
                  className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 focus:ring-2 focus:ring-[#0A3D62]"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                />
              </motion.div>
            )}
          </div>
        </section>

        <section className="space-y-4">
          <h3 className="font-bold border-b pb-2 dark:border-gray-700">Vehículo</h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold uppercase text-gray-500">Marca</label>
              <select 
                className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700"
                value={formData.brand}
                onChange={e => setFormData({ ...formData, brand: e.target.value })}
              >
                {carBrands.map(b => <option key={b.marca} value={b.marca}>{b.marca}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-gray-500">Modelo</label>
              <select 
                className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700"
                value={formData.model}
                onChange={e => setFormData({ ...formData, model: e.target.value })}
              >
                {availableModels.map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-gray-500">Año</label>
              <input 
                type="number" 
                className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700"
                value={formData.year}
                onChange={e => setFormData({ ...formData, year: e.target.value })}
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-gray-500">Versión</label>
              <input 
                type="text" 
                className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700"
                value={formData.version}
                onChange={e => setFormData({ ...formData, version: e.target.value })}
              />
            </div>
          </div>
        </section>
      </div>

      <section className="mt-8 space-y-4">
        <div className="flex justify-between items-center border-b pb-2 dark:border-gray-700">
          <h3 className="font-bold">Piezas</h3>
          <button 
            onClick={() => addPart()}
            className="text-[#0A3D62] dark:text-blue-400 flex items-center gap-1 text-sm font-bold"
          >
            <Plus className="w-4 h-4" /> AGREGAR PIEZA
          </button>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {quickParts.map((part, i) => (
            <button 
              key={i}
              onClick={() => setParts([...parts, { 
                name: part.nombre, 
                side: part.lado, 
                position: part.posicion, 
                height: part.altura 
              }])}
              className="px-3 py-1.5 bg-gray-100 dark:bg-gray-800 hover:bg-[#0A3D62] hover:text-white rounded-lg text-xs font-medium transition-colors"
            >
              {part.nombre}
            </button>
          ))}
        </div>

        <div className="space-y-3">
          {parts.map((part, idx) => (
            <div key={idx} className="flex flex-wrap md:flex-nowrap gap-2 items-end bg-gray-50 dark:bg-gray-800/50 p-3 rounded-xl border dark:border-gray-700">
              <div className="flex-1 min-w-[150px]">
                <label className="text-[10px] font-bold uppercase text-gray-400">Pieza</label>
                <input 
                  type="text" 
                  className="w-full p-2 bg-transparent border-b dark:border-gray-600 focus:border-[#0A3D62] outline-none"
                  value={part.name}
                  onChange={e => {
                    const newParts = [...parts];
                    newParts[idx].name = e.target.value;
                    setParts(newParts);
                  }}
                />
              </div>
              <div className="w-24">
                <label className="text-[10px] font-bold uppercase text-gray-400">Lado</label>
                <select 
                  className="w-full p-2 bg-transparent border-b dark:border-gray-600 outline-none"
                  value={part.side}
                  onChange={e => {
                    const newParts = [...parts];
                    newParts[idx].side = e.target.value;
                    setParts(newParts);
                  }}
                >
                  <option value="N/A">N/A</option>
                  <option value="Derecho">Derecho</option>
                  <option value="Izquierdo">Izquierdo</option>
                </select>
              </div>
              <div className="w-24">
                <label className="text-[10px] font-bold uppercase text-gray-400">Posición</label>
                <select 
                  className="w-full p-2 bg-transparent border-b dark:border-gray-600 outline-none"
                  value={part.position}
                  onChange={e => {
                    const newParts = [...parts];
                    newParts[idx].position = e.target.value;
                    setParts(newParts);
                  }}
                >
                  <option value="N/A">N/A</option>
                  <option value="Delantero">Delantero</option>
                  <option value="Trasero">Trasero</option>
                </select>
              </div>
              <div className="w-24">
                <label className="text-[10px] font-bold uppercase text-gray-400">Altura</label>
                <select 
                  className="w-full p-2 bg-transparent border-b dark:border-gray-600 outline-none"
                  value={part.height}
                  onChange={e => {
                    const newParts = [...parts];
                    newParts[idx].height = e.target.value;
                    setParts(newParts);
                  }}
                >
                  <option value="N/A">N/A</option>
                  <option value="Superior">Superior</option>
                  <option value="Inferior">Inferior</option>
                </select>
              </div>
              <button 
                onClick={() => removePart(idx)}
                className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
        <section className="space-y-4">
          <h3 className="font-bold border-b pb-2 dark:border-gray-700">Evidencia Visual</h3>
          <div className="flex flex-wrap gap-3">
            <label className="w-24 h-24 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-xl flex flex-col items-center justify-center cursor-pointer hover:border-[#0A3D62] transition-colors">
              <Camera className="w-8 h-8 text-gray-400" />
              <span className="text-[10px] font-bold text-gray-400">FOTO</span>
              <input type="file" capture="environment" accept="image/*" multiple className="hidden" onChange={handleImageChange} />
            </label>
            {images.map((img, i) => (
              <div key={i} className="relative w-24 h-24 rounded-xl overflow-hidden shadow-md">
                <img src={img} alt="preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <button 
                  onClick={() => setImages(images.filter((_, idx) => idx !== i))}
                  className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </section>

        <section className="space-y-4">
          <h3 className="font-bold border-b pb-2 dark:border-gray-700">Notas Adicionales</h3>
          <textarea 
            className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 h-24"
            placeholder="Detalles específicos..."
            value={formData.notes}
            onChange={e => setFormData({ ...formData, notes: e.target.value })}
          />
          <div className={cn(
            "p-4 rounded-xl border-2 flex items-center justify-between transition-all",
            formData.isUrgent ? "border-red-500 bg-red-50 dark:bg-red-900/20" : "border-gray-200 dark:border-gray-700"
          )}>
            <div className="flex items-center gap-3">
              <AlertCircle className={cn("w-6 h-6", formData.isUrgent ? "text-red-500" : "text-gray-400")} />
              <div>
                <p className="font-bold text-sm">MARCAR COMO URGENTE</p>
                <p className="text-xs text-gray-500">Prioridad máxima en el tablero</p>
              </div>
            </div>
            <input 
              type="checkbox" 
              className="w-6 h-6 rounded-full accent-red-500"
              checked={formData.isUrgent}
              onChange={e => setFormData({ ...formData, isUrgent: e.target.checked })}
            />
          </div>
        </section>
      </div>

      <div className="mt-12 flex flex-col md:flex-row gap-4">
        <button 
          onClick={() => handleSubmit(false)}
          className="flex-1 bg-[#0A3D62] hover:bg-[#0c4a77] text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-lg transition-transform active:scale-95"
        >
          <Send className="w-6 h-6" /> GENERAR PEDIDO
        </button>
        <button 
          onClick={() => handleSubmit(true)}
          className="flex-1 bg-white dark:bg-gray-800 border-2 border-[#0A3D62] text-[#0A3D62] dark:text-blue-400 py-4 rounded-2xl font-bold flex items-center justify-center gap-3 transition-transform active:scale-95"
        >
          <Save className="w-6 h-6" /> SOLO GUARDAR
        </button>
      </div>
    </motion.div>
  );
}

// Missing icon import in original code, adding it here
import { Trash2 } from 'lucide-react';
