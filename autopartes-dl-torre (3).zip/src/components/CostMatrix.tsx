import React, { useState, useEffect } from 'react';
import { 
  Copy, 
  Save, 
  Table as TableIcon, 
  X, 
  Plus, 
  Phone,
  ChevronLeft,
  User,
  Car,
  MapPin,
  FileText,
  ChevronDown,
  ChevronUp,
  Users
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Quote, AppConfig, Provider, getProviders, getQuotes } from '../db';
import { cn, formatWhatsApp } from '../utils';
import { optimizeImage } from '../lib/imageUtils';

interface CostMatrixProps {
  quote: Quote;
  config: AppConfig;
  onSave: (q: Quote) => void;
  onBack: () => void;
}

export default function CostMatrix({ quote, config, onSave, onBack }: CostMatrixProps) {
  const [isEditMode, setIsEditMode] = useState(true);
  const [showClientData, setShowClientData] = useState(false);
  const [localQuote, setLocalQuote] = useState<Quote>(quote);
  const [globalProviders, setGlobalProviders] = useState<(Provider & { frequency: number })[]>([]);

  useEffect(() => {
    loadGlobalProviders();
  }, []);

  const loadGlobalProviders = async () => {
    const [providers, allQuotes] = await Promise.all([
      getProviders(),
      getQuotes()
    ]);
    
    // Calculate frequency of use in historical quotes
    const frequency: Record<string, number> = {};
    allQuotes.forEach(q => {
      q.providers.forEach(p => {
        frequency[p.id] = (frequency[p.id] || 0) + 1;
      });
    });

    const sorted = providers.map(p => ({
      ...p,
      frequency: frequency[p.id] || 0
    })).sort((a, b) => b.frequency - a.frequency || a.name.localeCompare(b.name));

    setGlobalProviders(sorted);
  };

  const handlePriceChange = (partId: string, providerId: string, value: string) => {
    const price = parseInt(value) || 0;
    const newParts = localQuote.parts.map(p => {
      if (p.id === partId) {
        return { ...p, prices: { ...p.prices, [providerId]: price } };
      }
      return p;
    });
    const updatedQuote = { ...localQuote, parts: newParts };
    setLocalQuote(updatedQuote);
  };

  const handleSalePriceChange = (partId: string, value: string) => {
    const price = parseInt(value) || 0;
    const newParts = localQuote.parts.map(p => {
      if (p.id === partId) {
        return { ...p, salePrice: price };
      }
      return p;
    });
    const updatedQuote = { ...localQuote, parts: newParts };
    setLocalQuote(updatedQuote);
    // Reactive persistence: save to DB on change
    onSave(updatedQuote);
  };

  const handleToggleHunting = (partId: string, value: boolean) => {
    const newParts = localQuote.parts.map(p => {
      if (p.id === partId) {
        return { ...p, isHunting: value };
      }
      return p;
    });
    const updatedQuote = { ...localQuote, parts: newParts };
    setLocalQuote(updatedQuote);
    onSave(updatedQuote);
  };

  const handleNotesChange = (value: string) => {
    const updatedQuote = { ...localQuote, notes: value };
    setLocalQuote(updatedQuote);
    onSave(updatedQuote);
  };

  const addPart = () => {
    const newPart = {
      id: crypto.randomUUID(),
      name: '',
      side: 'N/A',
      position: 'N/A',
      height: 'N/A',
      prices: {},
      isHunting: false
    };
    const updatedQuote = { ...localQuote, parts: [...localQuote.parts, newPart] };
    setLocalQuote(updatedQuote);
    onSave(updatedQuote);
  };

  const removePart = (partId: string) => {
    if (confirm('¿Estás seguro de eliminar esta pieza?')) {
      const updatedQuote = { ...localQuote, parts: localQuote.parts.filter(p => p.id !== partId) };
      setLocalQuote(updatedQuote);
      onSave(updatedQuote);
    }
  };

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      try {
        const optimizedImages = await Promise.all(
          Array.from(files).map((file: File) => optimizeImage(file))
        );
        const updatedQuote = { ...localQuote, images: [...(localQuote.images || []), ...optimizedImages] };
        setLocalQuote(updatedQuote);
        onSave(updatedQuote);
      } catch (error) {
        console.error('Error optimizando imágenes:', error);
        alert('Error al procesar las imágenes');
      }
    }
  };

  const saveChanges = async () => {
    await onSave(localQuote);
    alert('Cambios guardados correctamente');
  };

  const getTotalSalePrice = () => {
    return localQuote.parts.reduce((acc, p) => acc + (p.salePrice || 0), 0);
  };

  const sendWhatsAppQuote = () => {
    const partsList = localQuote.parts
      .filter(p => p.salePrice && p.salePrice > 0)
      .map(p => {
        const side = p.side && p.side !== 'N/A' ? p.side : '';
        const position = p.position && p.position !== 'N/A' ? p.position : '';
        const height = p.height && p.height !== 'N/A' ? p.height : '';
        const fullName = `${p.name} ${side} ${position} ${height}`.replace(/\s+/g, ' ').trim();
        return `${fullName} - $${p.salePrice}`;
      })
      .join('\n');

    const total = getTotalSalePrice();
    const message = `Cotización de Autopartes DL Torre 🚗\n` +
      `Cliente: ${localQuote.clientName}\n` +
      `Vehículo: ${localQuote.brand} ${localQuote.model} ${localQuote.year}\n\n` +
      `*DETALLE DE PIEZAS:*\n` +
      `${partsList}\n` +
      `--------------------------\n` +
      `*TOTAL: $${total}*`;
    
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${localQuote.whatsapp.replace(/\D/g, '')}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  const getLowestPrice = (partId: string) => {
    const part = localQuote.parts.find(p => p.id === partId);
    if (!part) return null;
    const prices = Object.values(part.prices) as number[];
    const validPrices = prices.filter(p => p > 0);
    if (validPrices.length === 0) return null;
    return Math.min(...validPrices);
  };

  const copyHuntMode = () => {
    if (!localQuote || !localQuote.parts) return;

    const newParts = localQuote.parts.map(p => ({ ...p, isHunting: true }));
    
    const partsList = newParts
      .map(p => {
        const side = p.side && p.side !== 'N/A' ? p.side : '';
        const position = p.position && p.position !== 'N/A' ? p.position : '';
        const height = p.height && p.height !== 'N/A' ? p.height : '';
        const fullName = `${p.name} ${side} ${position} ${height}`.replace(/\s+/g, ' ').trim();
        return fullName ? `- ${fullName}` : null;
      })
      .filter(Boolean)
      .join('\n');

    const text = `Hola, estoy buscando piezas para: *${localQuote.brand || ''} ${localQuote.model || ''} ${localQuote.year || ''}*\n\n` +
      `Tienes las siguientes piezas?:\n\n` +
      `${partsList}\n\n\n` +
      `si las tienes pasame precio y foto de cada una. Gracias. Autopartes DLTorre, Guadalajara, Vallarta, Mezcales y Monterrey\n\n` +
      `🦈🦈🦈🦈🦈 🏢🏢🏢🏢🏢\n\n` +
      `COTIZACIÓN: *${localQuote.quoteNumber || ''}*`;
    
    const updatedQuote = { ...localQuote, parts: newParts, isHunting: true };
    setLocalQuote(updatedQuote);
    onSave(updatedQuote);
    
    navigator.clipboard.writeText(text);
    alert('Texto copiado para proveedores. Modo Cacería activado para todos los artículos.');
  };

  const getProviderWhatsAppMessage = (providerId: string, providerName: string) => {
    if (!localQuote || !localQuote.parts) return '';

    const quotedParts = localQuote.parts
      .filter(p => p.prices && p.prices[providerId] && p.prices[providerId] > 0)
      .map(p => {
        const side = p.side && p.side !== 'N/A' ? p.side : '';
        const position = p.position && p.position !== 'N/A' ? p.position : '';
        const height = p.height && p.height !== 'N/A' ? p.height : '';
        const fullName = `${p.name} ${side} ${position} ${height}`.replace(/\s+/g, ' ').trim();
        return `- ${fullName} - $${p.prices[providerId]}`;
      })
      .join('\n');

    return `Hola *${providerName}*:\n\n` +
      `Me cotizaste estas piezas:\n\n` +
      `${quotedParts}\n\n` +
      `El cliente si esta interesado, me puedes confirmar que si las tienes aun? Gracias, Autopartes DLTorre, Guadalajara, Vallarta, Mezcales y Monterrey`;
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="bg-white dark:bg-[#1e1e1e] rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[85vh]"
    >
      {/* HEADER */}
      <div className="bg-[#0A3D62] text-white p-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h2 className="text-lg font-bold leading-tight">{localQuote.brand} {localQuote.model} {localQuote.year}</h2>
            <p className="text-xs opacity-80">{localQuote.quoteNumber} • {localQuote.clientName}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setShowClientData(!showClientData)}
            className={cn(
              "p-2 rounded-lg flex items-center gap-2 text-sm font-bold transition-colors",
              showClientData ? "bg-white text-[#0A3D62]" : "bg-white/10 hover:bg-white/20"
            )}
          >
            <User className="w-4 h-4" /> {showClientData ? 'OCULTAR DATOS' : 'EDITAR DATOS'}
          </button>
          <button 
            onClick={() => setIsEditMode(!isEditMode)}
            className={cn(
              "p-2 rounded-lg flex items-center gap-2 text-sm font-bold transition-colors",
              isEditMode ? "bg-amber-500 text-white" : "bg-white/10 hover:bg-white/20"
            )}
          >
            {isEditMode ? <Save className="w-4 h-4" /> : <TableIcon className="w-4 h-4" />}
            {isEditMode ? 'MODO EDICIÓN' : 'MODO VISTA'}
          </button>
        </div>
      </div>

      {/* CLIENT DATA EDITOR (COLLAPSIBLE) */}
      <AnimatePresence>
        {showClientData && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-gray-50 dark:bg-gray-800 border-b dark:border-gray-700 overflow-hidden"
          >
            <div className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Cliente</label>
                <input 
                  type="text" 
                  className="w-full p-2 rounded-lg border dark:bg-gray-900 dark:border-gray-700"
                  value={localQuote.clientName}
                  onChange={e => setLocalQuote({ ...localQuote, clientName: e.target.value })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">WhatsApp</label>
                <input 
                  type="text" 
                  className="w-full p-2 rounded-lg border dark:bg-gray-900 dark:border-gray-700"
                  value={localQuote.whatsapp}
                  onChange={e => setLocalQuote({ ...localQuote, whatsapp: e.target.value })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Ubicación</label>
                <input 
                  type="text" 
                  className="w-full p-2 rounded-lg border dark:bg-gray-900 dark:border-gray-700"
                  value={localQuote.location}
                  onChange={e => setLocalQuote({ ...localQuote, location: e.target.value })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Vehículo</label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    placeholder="Marca"
                    className="w-1/3 p-2 rounded-lg border dark:bg-gray-900 dark:border-gray-700"
                    value={localQuote.brand}
                    onChange={e => setLocalQuote({ ...localQuote, brand: e.target.value })}
                  />
                  <input 
                    type="text" 
                    placeholder="Modelo"
                    className="w-1/3 p-2 rounded-lg border dark:bg-gray-900 dark:border-gray-700"
                    value={localQuote.model}
                    onChange={e => setLocalQuote({ ...localQuote, model: e.target.value })}
                  />
                  <input 
                    type="text" 
                    placeholder="Año"
                    className="w-1/3 p-2 rounded-lg border dark:bg-gray-900 dark:border-gray-700"
                    value={localQuote.year}
                    onChange={e => setLocalQuote({ ...localQuote, year: e.target.value })}
                  />
                </div>
              </div>
              <div className="md:col-span-2 space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Notas</label>
                <input 
                  type="text" 
                  className="w-full p-2 rounded-lg border dark:bg-gray-900 dark:border-gray-700"
                  value={localQuote.notes}
                  onChange={e => setLocalQuote({ ...localQuote, notes: e.target.value })}
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MATRIX TABLE */}
      <div className="flex-1 overflow-auto">
        <div className="p-4 flex flex-col gap-6">
          <div className="overflow-x-auto rounded-xl border dark:border-gray-700">
            <table className="w-full border-collapse text-sm">
          <thead className="sticky top-0 z-20 bg-gray-100 dark:bg-gray-800 shadow-sm">
            <tr>
              <th className="sticky left-0 z-30 bg-gray-100 dark:bg-gray-800 p-4 text-left border-b dark:border-gray-700 min-w-[200px] font-bold uppercase text-[10px] text-gray-500">
                <div className="flex items-center gap-2">
                  <span>Producto / Pieza</span>
                </div>
              </th>
              <th className="p-4 text-center border-b dark:border-gray-700 min-w-[60px] font-bold uppercase text-[10px] text-gray-500">
                Caza
              </th>
              <th className="p-4 text-center border-b dark:border-gray-700 min-w-[150px] bg-blue-50/50 dark:bg-blue-900/20">
                <span className="font-bold uppercase text-[10px] text-blue-600 dark:text-blue-400">Precio de Venta</span>
              </th>
              {localQuote.providers.map(provider => (
                <th key={provider.id} className="p-4 text-center border-b dark:border-gray-700 min-w-[150px]">
                  <div className="flex flex-col items-center gap-1">
                    <div className="flex items-center gap-1">
                      <span className="font-bold uppercase text-[10px] text-gray-500">{provider.name}</span>
                      {isEditMode && (
                        <button 
                          onClick={() => {
                            const updated = localQuote.providers.filter(p => p.id !== provider.id);
                            setLocalQuote({ ...localQuote, providers: updated });
                          }}
                          className="text-red-500 hover:text-red-700"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    {provider.phone && (
                      <a 
                        href={formatWhatsApp(provider.phone, getProviderWhatsAppMessage(provider.id, provider.name))}
                        target="_blank"
                        className="text-emerald-500 hover:scale-110 transition-transform"
                      >
                        <Phone className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </th>
              ))}
              {isEditMode && (
                <th className="p-4 text-center border-b dark:border-gray-700 min-w-[80px]">
                  <button 
                    onClick={addPart}
                    className="text-emerald-500 hover:text-emerald-700 text-[10px] font-bold flex items-center justify-center gap-1 uppercase bg-emerald-50 dark:bg-emerald-900/20 p-3 rounded-xl transition-all"
                    title="Agregar Pieza"
                  >
                    <Plus className="w-4 h-4" /> PIEZA
                  </button>
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {localQuote.parts.map((part, idx) => {
              const lowest = getLowestPrice(part.id);
              return (
                <tr key={part.id} className={cn(
                  "hover:bg-blue-50/30 dark:hover:bg-blue-900/10 transition-colors",
                  idx % 2 === 0 ? "bg-white dark:bg-[#1e1e1e]" : "bg-gray-50/50 dark:bg-gray-800/30",
                  part.isHunting && "bg-amber-50 dark:bg-amber-900/20"
                )}>
                  <td className="sticky left-0 z-10 bg-inherit p-4 border-b dark:border-gray-700 font-medium">
                    <div className="flex flex-col">
                      {isEditMode ? (
                        <input 
                          type="text" 
                          className="bg-transparent border-b border-gray-200 dark:border-gray-700 focus:border-blue-500 outline-none p-1"
                          value={part.name}
                          onChange={e => {
                            const newParts = localQuote.parts.map(p => p.id === part.id ? { ...p, name: e.target.value } : p);
                            setLocalQuote({ ...localQuote, parts: newParts });
                          }}
                        />
                      ) : (
                        <span>{part.name}</span>
                      )}
                      <span className="text-[10px] text-gray-400 uppercase">{part.side} {part.position} {part.height}</span>
                    </div>
                  </td>
                  <td className="p-2 border-b dark:border-gray-700 text-center">
                    <input 
                      type="checkbox" 
                      checked={!!part.isHunting}
                      onChange={e => handleToggleHunting(part.id, e.target.checked)}
                      className="w-5 h-5 rounded border-gray-300 text-amber-600 focus:ring-amber-600 cursor-pointer"
                    />
                  </td>
                  <td className="p-2 border-b dark:border-gray-700 text-center bg-blue-50/30 dark:bg-blue-900/10">
                    <input 
                      type="number" 
                      className={cn(
                        "w-full p-2 text-center rounded-lg border-2 outline-none transition-all",
                        "border-blue-200 dark:border-blue-800 focus:border-blue-500 dark:bg-[#1e1e1e] font-bold text-blue-700 dark:text-blue-400"
                      )}
                      value={part.salePrice || ''}
                      onChange={e => handleSalePriceChange(part.id, e.target.value)}
                      placeholder="0"
                    />
                  </td>
                  {localQuote.providers.map(provider => {
                    const price = part.prices[provider.id] || 0;
                    const isLowest = lowest !== null && price === lowest && price > 0;
                    
                    return (
                      <td key={provider.id} className="p-2 border-b dark:border-gray-700 text-center">
                        {isEditMode ? (
                          <input 
                            type="number" 
                            className={cn(
                              "w-full p-2 text-center rounded-lg border-2 outline-none transition-all",
                              isLowest 
                                ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 font-bold text-emerald-700 dark:text-emerald-400" 
                                : "border-transparent focus:border-blue-500 dark:bg-gray-800"
                            )}
                            value={price || ''}
                            onChange={e => handlePriceChange(part.id, provider.id, e.target.value)}
                            placeholder="0"
                          />
                        ) : (
                          <span className={cn(
                            "text-lg",
                            isLowest ? "text-emerald-600 dark:text-emerald-400 font-black" : "text-gray-500"
                          )}>
                            {price > 0 ? `$${price}` : '—'}
                          </span>
                        )}
                      </td>
                    );
                  })}
                  {isEditMode && (
                    <td className="p-2 border-b dark:border-gray-700 text-center bg-gray-50/50 dark:bg-gray-800/20">
                      <button 
                        onClick={() => removePart(part.id)}
                        className="text-red-500 hover:text-red-700 p-2"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* GESTIÓN DE PROVEEDORES Y PRECIOS (NUEVA SECCIÓN FIJA) */}
      <div className="bg-white dark:bg-[#1e1e1e] p-6 rounded-2xl border-2 border-[#0A3D62]/10 dark:border-blue-900/10 shadow-sm space-y-5 relative overflow-hidden">
        {/* Raceway Accents */}
        <div className="absolute top-0 right-0 w-24 h-24 bg-[repeating-linear-gradient(45deg,#0A3D62,#0A3D62_10px,#0d4d7a_10px,#0d4d7a_20px)] opacity-5 rotate-45 translate-x-12 -translate-y-12"></div>
        <div className="absolute top-0 left-0 w-full h-[2px] bg-[repeating-linear-gradient(90deg,#0A3D62, #0A3D62_10px,transparent_10px,transparent_20px)] opacity-10"></div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 relative z-10">
          <div>
            <h3 className="text-sm font-black text-[#0A3D62] dark:text-blue-400 uppercase tracking-widest flex items-center gap-2">
              <Users className="w-5 h-5" /> Gestión de Proveedores
            </h3>
            <p className="text-[10px] text-gray-500 uppercase mt-1 font-bold">Asigna proveedores para comparar costos</p>
          </div>
          <button 
            onClick={() => {
              const name = prompt('Nombre del proveedor temporal/NUEVO:');
              const phone = prompt('WhatsApp (opcional):');
              if (name) {
                const newProvider = { id: crypto.randomUUID(), name, phone: phone || '', frequency: 0 };
                setLocalQuote({ ...localQuote, providers: [...localQuote.providers, newProvider] });
              }
            }}
            className="min-h-[44px] px-6 bg-[#0A3D62] text-white rounded-xl font-bold text-xs flex items-center gap-2 shadow-lg shadow-blue-900/20 active:scale-95 transition-all uppercase"
          >
            <Plus className="w-4 h-4" /> Agregar Nuevo
          </button>
        </div>

        {/* Limit to ~5 rows (row height ~60px, so 300px max height is perfect) */}
        <div className="flex flex-wrap gap-3 max-h-[140px] overflow-y-auto p-1 pr-2 scrollbar-thin scrollbar-thumb-[#0A3D62]/20 dark:scrollbar-thumb-blue-900/40 overscroll-contain relative z-10 pb-4">
          {globalProviders.length > 0 ? (
            globalProviders.map(gp => {
              const isAlreadyAdded = localQuote.providers.some(p => p.id === gp.id);
              return (
                <button
                  key={gp.id}
                  onClick={() => {
                    if (isAlreadyAdded) {
                      setLocalQuote({
                        ...localQuote,
                        providers: localQuote.providers.filter(p => p.id !== gp.id)
                      });
                    } else {
                      setLocalQuote({
                        ...localQuote,
                        providers: [...localQuote.providers, gp]
                      });
                    }
                  }}
                  className={cn(
                    "min-h-[52px] px-6 rounded-2xl font-bold text-sm transition-all flex items-center gap-3 border-2 shadow-sm relative overflow-hidden",
                    isAlreadyAdded 
                      ? "bg-[#0A3D62] text-white border-[#0A3D62] ring-4 ring-[#0A3D62]/10" 
                      : "bg-white dark:bg-gray-800 text-[#0A3D62] dark:text-gray-400 border-gray-100 dark:border-gray-700 hover:border-[#0A3D62]/30"
                  )}
                >
                  {isAlreadyAdded ? (
                    <div className="w-5 h-5 bg-white/20 rounded-full flex items-center justify-center">
                      <X className="w-3 h-3 text-white" />
                    </div>
                  ) : (
                    <Plus className="w-4 h-4 text-[#0A3D62]/40" />
                  )}
                  <span className="relative z-10">{gp.name}</span>
                  {gp.frequency > 5 && !isAlreadyAdded && (
                    <div className="absolute top-0 right-0 px-2 py-0.5 bg-amber-500 text-[8px] text-white rounded-bl-lg font-black uppercase">Frecuente</div>
                  )}
                </button>
              );
            })
          ) : (
            <div className="w-full p-10 text-center border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-3xl">
              <p className="text-gray-400 text-sm italic">No hay proveedores registrados.</p>
              <p className="text-[10px] text-[#0A3D62] font-black uppercase mt-2">Tablero &rarr; Proveedores</p>
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6 mt-4">
        {/* SIDEBAR: NOTES & IMAGES (Redesigned for the new layout) */}
        <div className="flex-1 space-y-2">
          <label className="text-[10px] font-bold text-gray-400 uppercase flex items-center gap-2">
            <FileText className="w-3 h-3" /> Notas y Observaciones
          </label>
          <textarea 
            className="w-full p-4 rounded-2xl border dark:bg-gray-900 dark:border-gray-700 text-sm h-32 resize-none outline-none focus:ring-2 focus:ring-[#0A3D62] transition-all shadow-inner"
            placeholder="Escribe detalles adicionales aquí..."
            value={localQuote.notes}
            onChange={e => handleNotesChange(e.target.value)}
          />
        </div>

        <div className="w-full lg:w-96 space-y-2">
          <label className="text-[10px] font-bold text-gray-400 uppercase flex items-center gap-2">
            <Car className="w-3 h-3" /> Fotos de Referencia
          </label>
          <div className="grid grid-cols-3 gap-2">
            {localQuote.images?.map((img, i) => (
              <div key={i} className="aspect-square rounded-xl overflow-hidden bg-gray-200 dark:bg-gray-900 relative group border dark:border-gray-700">
                <img src={img} alt="Ref" className="w-full h-full object-cover" />
                <button 
                  onClick={() => {
                    const updated = localQuote.images.filter((_, idx) => idx !== i);
                    setLocalQuote({ ...localQuote, images: updated });
                    onSave({ ...localQuote, images: updated });
                  }}
                  className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
            <label className="aspect-square rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-700 flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 transition-colors group bg-gray-50 dark:bg-gray-900/50">
              <Plus className="w-6 h-6 text-gray-400 group-hover:text-blue-500" />
              <span className="text-[8px] font-bold text-gray-400 group-hover:text-blue-500 uppercase">Añadir</span>
              <input type="file" className="hidden" accept="image/*" multiple onChange={handleImageSelect} />
            </label>
          </div>
        </div>
      </div>
    </div>
  </div>

      {/* TOOLBAR UNIFICADA */}
      <div className="p-4 bg-gray-50 dark:bg-gray-800 border-t dark:border-gray-700 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex gap-4 items-center">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
            <span className="text-xs font-bold text-gray-500 uppercase">Mejor Precio</span>
          </div>
          <button 
            onClick={copyHuntMode}
            className="text-[#0A3D62] dark:text-blue-400 text-xs font-bold flex items-center gap-1 hover:underline"
          >
            <Copy className="w-4 h-4" /> MODO CACERÍA (COPIAR)
          </button>
        </div>
        
        <div className="flex gap-3 w-full md:w-auto">
          <button 
            onClick={sendWhatsAppQuote}
            className="flex-1 md:flex-none px-6 py-3 bg-emerald-500 text-white rounded-xl font-bold shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 uppercase text-sm"
          >
            <Phone className="w-5 h-5" /> Enviar WhatsApp
          </button>
          <button 
            onClick={onBack}
            className="flex-1 md:flex-none px-6 py-3 rounded-xl font-bold text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors uppercase text-sm"
          >
            Cerrar
          </button>
          <button 
            onClick={saveChanges}
            className="flex-1 md:flex-none px-10 py-3 bg-[#0A3D62] text-white rounded-xl font-bold shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 uppercase text-sm"
          >
            <Save className="w-5 h-5" /> GUARDAR CAMBIOS
          </button>
        </div>
      </div>
    </motion.div>
  );
}
