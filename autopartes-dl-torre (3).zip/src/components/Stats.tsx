import React, { useMemo } from 'react';
import { 
  BarChart3 
} from 'lucide-react';
import { motion } from 'motion/react';
import { Quote } from '../db';

interface StatsProps {
  quotes: Quote[];
}

export default function Stats({ quotes }: StatsProps) {
  const stats = useMemo(() => {
    const now = new Date();
    const thisMonth = now.getMonth();
    const thisYear = now.getFullYear();

    const monthQuotes = quotes.filter(q => {
      const d = new Date(q.createdAt);
      return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
    });

    const completed = quotes.filter(q => q.status === 'vendido').length;
    const brands = quotes.reduce((acc, q) => {
      acc[q.brand] = (acc[q.brand] || 0) + 1;
      return acc;
    }, {} as { [k: string]: number });

    const locations = quotes.reduce((acc, q) => {
      acc[q.location] = (acc[q.location] || 0) + 1;
      return acc;
    }, {} as { [k: string]: number });

    return {
      total: quotes.length,
      monthTotal: monthQuotes.length,
      completionRate: quotes.length > 0 ? (completed / quotes.length) * 100 : 0,
      topBrands: Object.entries(brands).sort((a, b) => b[1] - a[1]).slice(0, 5),
      topLocations: Object.entries(locations).sort((a, b) => b[1] - a[1]).slice(0, 5)
    };
  }, [quotes]);

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
      <h2 className="text-2xl font-bold flex items-center gap-2">
        <BarChart3 className="text-emerald-500" /> Estadísticas de Negocio
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-[#1e1e1e] p-6 rounded-2xl shadow-sm border dark:border-gray-800">
          <p className="text-xs font-bold text-gray-400 uppercase mb-1">Cotizaciones del Mes</p>
          <p className="text-4xl font-black text-[#0A3D62] dark:text-blue-400">{stats.monthTotal}</p>
          <div className="mt-2 h-1 w-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 w-2/3"></div>
          </div>
        </div>
        <div className="bg-white dark:bg-[#1e1e1e] p-6 rounded-2xl shadow-sm border dark:border-gray-800">
          <p className="text-xs font-bold text-gray-400 uppercase mb-1">% de Conversión</p>
          <p className="text-4xl font-black text-emerald-500">{stats.completionRate.toFixed(1)}%</p>
          <div className="mt-2 h-1 w-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
            <div className="h-full bg-emerald-500" style={{ width: `${stats.completionRate}%` }}></div>
          </div>
        </div>
        <div className="bg-white dark:bg-[#1e1e1e] p-6 rounded-2xl shadow-sm border dark:border-gray-800">
          <p className="text-xs font-bold text-gray-400 uppercase mb-1">Total Histórico</p>
          <p className="text-4xl font-black text-slate-600 dark:text-slate-400">{stats.total}</p>
          <div className="mt-2 h-1 w-full bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
            <div className="h-full bg-slate-400 w-full"></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-[#1e1e1e] p-6 rounded-2xl shadow-sm border dark:border-gray-800">
          <h3 className="font-bold mb-4 flex items-center gap-2">Marcas más Cotizadas</h3>
          <div className="space-y-4">
            {stats.topBrands.map(([brand, count]) => (
              <div key={brand}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">{brand}</span>
                  <span className="font-bold">{count}</span>
                </div>
                <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full bg-[#0A3D62] dark:bg-blue-500" style={{ width: `${(count / stats.total) * 100}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white dark:bg-[#1e1e1e] p-6 rounded-2xl shadow-sm border dark:border-gray-800">
          <h3 className="font-bold mb-4 flex items-center gap-2">Poblaciones Principales</h3>
          <div className="space-y-4">
            {stats.topLocations.map(([loc, count]) => (
              <div key={loc}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">{loc}</span>
                  <span className="font-bold">{count}</span>
                </div>
                <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full bg-emerald-500" style={{ width: `${(count / stats.total) * 100}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
