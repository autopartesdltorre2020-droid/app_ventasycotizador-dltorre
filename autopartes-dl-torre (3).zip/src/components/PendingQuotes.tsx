import React, { useState, useMemo } from 'react';
import { 
  Clock, 
  Trash2, 
  ChevronLeft,
  Phone,
  Hash,
  Car,
  User
} from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';
import { Quote } from '../db';
import { cn, formatWhatsApp } from '../utils';
import SearchHeader from './SearchHeader';

interface PendingQuotesProps {
  quotes: Quote[];
  onSelect: (q: Quote) => void;
  onDelete: (id: string) => void;
  onClose: (id: string, status: 'vendido' | 'no_vendido') => void;
  onToggleNotified: (id: string, value: boolean) => void;
  onToggleHunting: (id: string, value: boolean) => void;
}

export default function PendingQuotes({ 
  quotes, 
  onSelect, 
  onDelete, 
  onClose, 
  onToggleNotified, 
  onToggleHunting
}: PendingQuotesProps) {
  const [search, setSearch] = useState('');

  const filteredQuotes = useMemo(() => {
    let result = [...quotes];

    if (search) {
      const term = search.toLowerCase().trim();
      const isFolioSearch = term.startsWith('cot-') || /^\d{1,4}$/.test(term);
      const isWhatsAppSearch = /^\d{5,}$/.test(term.replace(/\D/g, ''));

      result = result.filter(q => {
        if (isFolioSearch) return q.quoteNumber.toLowerCase().includes(term);
        if (isWhatsAppSearch) return q.whatsapp.replace(/\D/g, '').includes(term.replace(/\D/g, ''));
        return (
          q.brand.toLowerCase().includes(term) ||
          q.model.toLowerCase().includes(term) ||
          q.clientName.toLowerCase().includes(term) ||
          q.location.toLowerCase().includes(term)
        );
      });
    }

    return result.sort((a, b) => {
      if (a.isUrgent && !b.isUrgent) return -1;
      if (!a.isUrgent && b.isUrgent) return 1;
      return b.createdAt - a.createdAt;
    });
  }, [quotes, search]);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-4"
    >
      <SearchHeader 
        search={search}
        setSearch={setSearch}
        placeholder="Folio, WhatsApp o Modelo..."
        count={filteredQuotes.length}
        title="Cotizaciones Pendientes"
        icon={<Clock className="text-amber-500" />}
      />

      {filteredQuotes.length === 0 ? (
        <div className="text-center py-20 bg-white dark:bg-[#1e1e1e] rounded-2xl border-2 border-dashed border-gray-200 dark:border-gray-800">
          <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">
            {search ? `No se encontraron resultados para "${search}"` : "No hay cotizaciones pendientes"}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredQuotes.map(quote => {
            const totalParts = quote.parts.length;
            const pricedParts = quote.parts.filter(p => Object.keys(p.prices).length > 0).length;
            const progress = (pricedParts / totalParts) * 100;
            
            let statusColor = "bg-red-500";
            if (progress === 100) statusColor = "bg-blue-500";
            else if (progress > 0) statusColor = "bg-amber-500";

            return (
              <div 
                key={quote.id}
                className={cn(
                  "relative bg-white dark:bg-[#1e1e1e] rounded-2xl shadow-sm border-l-8 overflow-hidden transition-all hover:shadow-md cursor-pointer",
                  quote.isUrgent ? "border-l-[#0A3D62] dark:border-l-blue-600" : "border-l-gray-300 dark:border-l-gray-700",
                  quote.isNotified && "opacity-60 grayscale-[0.3]",
                  quote.isHunting && "bg-blue-50/50 dark:bg-blue-900/10 border-blue-200 dark:border-blue-800"
                )}
                onClick={() => onSelect(quote)}
              >
                <div className="p-5">
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-mono font-bold text-gray-400">{quote.quoteNumber}</span>
                        {quote.isUrgent && (
                          <span className="bg-[#0A3D62] text-white text-[10px] px-2 py-0.5 rounded-full font-bold">URGENTE</span>
                        )}
                        {quote.isNotified && (
                          <span className="bg-emerald-500 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">AVISADO</span>
                        )}
                        {quote.isHunting && (
                          <span className="bg-blue-600 text-white text-[10px] px-2 py-0.5 rounded-full font-bold">EN BÚSQUEDA</span>
                        )}
                      </div>
                      <h3 className="text-lg font-bold leading-tight">{quote.brand} {quote.model} {quote.year}</h3>
                      <div className="flex flex-col gap-0.5">
                        <p className="text-sm text-gray-500 font-medium">{quote.clientName} • {quote.location}</p>
                        <a 
                          href={formatWhatsApp(quote.whatsapp, '')} 
                          target="_blank" 
                          onClick={(e) => e.stopPropagation()}
                          className="text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 hover:underline"
                        >
                          <Phone className="w-3 h-3" /> {quote.whatsapp}
                        </a>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <button 
                        onClick={(e) => { e.stopPropagation(); onDelete(quote.id); }}
                        className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                      <label 
                        className="flex items-center gap-2 cursor-pointer p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <span className="text-[10px] font-bold text-gray-400 uppercase">Cacería</span>
                        <input 
                          type="checkbox" 
                          checked={!!quote.isHunting}
                          onChange={(e) => onToggleHunting(quote.id, e.target.checked)}
                          className="w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-600 cursor-pointer"
                        />
                      </label>
                      <label 
                        className="flex items-center gap-2 cursor-pointer p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <span className="text-[10px] font-bold text-gray-400 uppercase">Avisado</span>
                        <input 
                          type="checkbox" 
                          checked={!!quote.isNotified}
                          onChange={(e) => onToggleNotified(quote.id, e.target.checked)}
                          className="w-5 h-5 rounded border-gray-300 text-[#0A3D62] focus:ring-[#0A3D62] cursor-pointer"
                        />
                      </label>
                    </div>
                  </div>

                  <div className="space-y-2 mt-4">
                    <div className="flex justify-between text-xs font-bold">
                      <span className="text-gray-400 uppercase">Progreso de Precios</span>
                      <span className={cn(
                        progress === 100 ? "text-blue-500" : progress > 0 ? "text-amber-500" : "text-red-500"
                      )}>
                        {pricedParts}/{totalParts} PIEZAS
                      </span>
                    </div>
                    <div className="w-full h-1 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        className={cn("h-full transition-all duration-500", statusColor)}
                      />
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-800/50 px-5 py-3 flex justify-between items-center border-t dark:border-gray-700">
                  <span className="text-xs text-gray-400">{format(quote.createdAt, 'dd/MM/yyyy HH:mm')}</span>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={(e) => { e.stopPropagation(); onClose(quote.id, 'vendido'); }}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] px-3 py-1.5 rounded-lg font-bold transition-colors shadow-sm"
                    >
                      VENDIDO
                    </button>
                    <button 
                      onClick={(e) => { e.stopPropagation(); onClose(quote.id, 'no_vendido'); }}
                      className="bg-red-500/20 hover:bg-red-500/30 text-red-600 dark:text-red-400 text-[10px] px-3 py-1.5 rounded-lg font-bold transition-colors border border-red-500/20"
                    >
                      NO VENDIDO
                    </button>
                    <div className="flex items-center gap-1 text-[#0A3D62] dark:text-blue-400 text-xs font-bold ml-2">
                      GESTIONAR <ChevronLeft className="w-4 h-4 rotate-180" />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
