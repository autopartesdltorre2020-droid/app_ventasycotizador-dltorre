import React, { useState } from 'react';
import { 
  Settings, 
  Camera, 
  Trash2, 
  X, 
  FileJson, 
  Upload, 
  FileSpreadsheet, 
  Mail 
} from 'lucide-react';
import { motion } from 'motion/react';
import { format } from 'date-fns';
import { Quote, AppConfig, Provider, saveQuote } from '../db';
import { QuickPart, CarBrand } from './QuoteForm';
import { cn } from '../utils';

interface ConfigViewProps {
  config: AppConfig;
  quickParts: QuickPart[];
  carBrands: CarBrand[];
  onSave: (c: AppConfig) => void;
  onSaveQuickParts: (p: QuickPart[]) => void;
  onSaveCarBrands: (b: CarBrand[]) => void;
  quotes: Quote[];
}

export default function ConfigView({ 
  config, 
  quickParts, 
  carBrands, 
  onSave, 
  onSaveQuickParts, 
  onSaveCarBrands, 
  quotes 
}: ConfigViewProps) {
  const [activeTab, setActiveTab] = useState<'visual' | 'business' | 'parts' | 'brands' | 'data'>('visual');
  const [localConfig, setLocalConfig] = useState<AppConfig>(config);
  const [localQuickParts, setLocalQuickParts] = useState<QuickPart[]>(quickParts);
  const [localCarBrands, setLocalCarBrands] = useState<CarBrand[]>(carBrands);

  const handleExportCSV = () => {
    const headers = ["NumeroCotizacion", "Fecha", "NombreCliente", "WhatsApp", "Poblacion", "Marca", "Modelo", "Año", "Status", "Piezas", "Proveedores", "Precios"];
    const rows = quotes.map(q => {
      const partsText = q.parts.map(p => {
        const side = p.side !== 'N/A' ? p.side : '';
        const position = p.position !== 'N/A' ? p.position : '';
        const height = p.height !== 'N/A' ? p.height : '';
        return `${p.name} ${side} ${position} ${height}`.replace(/\s+/g, ' ').trim();
      }).join(' | ');

      const providersText = q.providers.map(p => `${p.name}:${p.phone}`).join(' | ');

      const pricesText = q.parts.map(p => {
        const partName = `${p.name} ${p.side !== 'N/A' ? p.side : ''} ${p.position !== 'N/A' ? p.position : ''} ${p.height !== 'N/A' ? p.height : ''}`.replace(/\s+/g, ' ').trim();
        const providerPrices = Object.entries(p.prices)
          .map(([providerId, price]) => {
            const provider = q.providers.find(prov => prov.id === providerId);
            return provider ? `${provider.name}:${price}` : null;
          })
          .filter(Boolean)
          .join(',');
        return providerPrices ? `${partName}>${providerPrices}` : null;
      }).filter(Boolean).join(';');

      return [
        q.quoteNumber,
        format(q.createdAt, 'dd/MM/yyyy'),
        q.clientName,
        q.whatsapp,
        q.location,
        q.brand,
        q.model,
        q.year,
        q.status,
        partsText,
        providersText,
        pricesText
      ];
    });

    const csvContent = [headers, ...rows].map(e => e.map(val => `"${val}"`).join(",")).join("\n");
    const blob = new Blob(["\ufeff" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `autopartes-cotizaciones-${format(new Date(), 'yyyyMMdd')}.csv`;
    a.click();
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        try {
          const text = ev.target?.result as string;
          const parseCSV = (str: string) => {
            const arr: string[][] = [];
            let quote = false;
            let row = 0;
            let col = 0;
            for (let c = 0; c < str.length; c++) {
              const char = str[c];
              const next = str[c + 1];
              arr[row] = arr[row] || [];
              arr[row][col] = arr[row][col] || '';
              if (char === '"' && quote && next === '"') { arr[row][col] += char; c++; continue; }
              if (char === '"') { quote = !quote; continue; }
              if (char === ',' && !quote) { col++; continue; }
              if (char === '\r' && next === '\n' && !quote) { row++; col = 0; c++; continue; }
              if (char === '\n' && !quote) { row++; col = 0; continue; }
              if (char === '\r' && !quote) { row++; col = 0; continue; }
              arr[row][col] += char;
            }
            return arr;
          };

          const rows = parseCSV(text).filter(r => r.length > 0 && r[0] !== '');
          const headers = rows[0];
          
          if (headers[0] !== "NumeroCotizacion") {
            alert('Formato CSV no válido');
            return;
          }

          const importedQuotes: Quote[] = rows.slice(1).map(values => {
            const data: any = {};
            headers.forEach((h, i) => data[h] = values[i]);

            const providers: Provider[] = (data.Proveedores || '').split(' | ').filter(Boolean).map((pStr: string) => {
              const [name, phone] = pStr.split(':');
              return { id: crypto.randomUUID(), name, phone: phone || '' };
            });

            const parts: any[] = (data.Piezas || '').split(' | ').filter(Boolean).map((pStr: string) => {
              const id = crypto.randomUUID();
              return {
                id,
                name: pStr,
                side: 'N/A',
                position: 'N/A',
                height: 'N/A',
                prices: {}
              };
            });

            if (data.Precios) {
              const priceEntries = data.Precios.split(';');
              priceEntries.forEach((entry: string) => {
                const [partName, providerData] = entry.split('>');
                if (partName && providerData) {
                  const part = parts.find(p => p.name === partName);
                  if (part) {
                    const provPrices = providerData.split(',');
                    provPrices.forEach(pp => {
                      const [provName, price] = pp.split(':');
                      const provider = providers.find(p => p.name === provName);
                      if (provider) {
                        part.prices[provider.id] = parseInt(price) || 0;
                      }
                    });
                  }
                }
              });
            }

            return {
              id: crypto.randomUUID(),
              quoteNumber: data.NumeroCotizacion,
              createdAt: new Date(data.Fecha.split('/').reverse().join('-')).getTime() || Date.now(),
              clientName: data.NombreCliente,
              whatsapp: data.WhatsApp,
              sameNumber: true,
              phone: '',
              location: data.Poblacion,
              brand: data.Marca,
              model: data.Modelo,
              year: data.Año,
              version: '',
              status: data.Status as any,
              parts,
              providers,
              notes: '',
              isUrgent: false,
              images: []
            };
          });

          for (const q of importedQuotes) {
            await saveQuote(q);
          }
          
          alert('Datos importados con éxito. La página se recargará.');
          window.location.reload();
        } catch (err) {
          console.error(err);
          alert('Error al importar CSV');
        }
      };
      reader.readAsText(file);
    }
  };

  const handleExport = () => {
    const data = JSON.stringify({ 
      config: localConfig, 
      quickParts: localQuickParts, 
      carBrands: localCarBrands 
    }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `autopartes-respaldo-${format(new Date(), 'yyyyMMdd')}.json`;
    a.click();
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        try {
          const imported = JSON.parse(ev.target?.result as string);
          if (imported.config || imported.quickParts || imported.carBrands) {
            if (imported.config) onSave(imported.config);
            if (imported.quickParts) onSaveQuickParts(imported.quickParts);
            if (imported.carBrands) onSaveCarBrands(imported.carBrands);
            
            alert('Datos importados con éxito. La página se recargará.');
            window.location.reload();
          }
        } catch (err) {
          alert('Error al importar archivo');
        }
      };
      reader.readAsText(file);
    }
  };

  const handleEmailBackup = () => {
    const data = JSON.stringify({ 
      config: localConfig, 
      quickParts: localQuickParts, 
      carBrands: localCarBrands,
      quotes 
    }, null, 2);
    const subject = `Respaldo Autopartes Pro - ${format(new Date(), 'dd/MM/yyyy')}`;
    const body = `Respaldo de datos (primeros 500 caracteres):\n\n${data.slice(0, 500)}...`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const tabs = [
    { id: 'visual', label: 'IDENTIDAD VISUAL', icon: Camera },
    { id: 'business', label: 'INFORMACIÓN DEL NEGOCIO', icon: Mail },
    { id: 'parts', label: 'BOTONES DE PIEZAS', icon: Settings },
    { id: 'brands', label: 'MARCAS Y MODELOS', icon: Settings },
    { id: 'data', label: 'RESPALDO Y DATOS', icon: FileJson },
  ];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col md:flex-row gap-6 max-w-6xl mx-auto min-h-[600px]">
      {/* SIDEBAR TABS */}
      <aside className="w-full md:w-72 space-y-2">
        <div className="bg-[#0A3D62] p-4 rounded-t-2xl">
          <h2 className="text-white font-black text-sm flex items-center gap-2 uppercase tracking-tight">
            <Settings className="w-4 h-4" /> Configuración
          </h2>
        </div>
        <nav className="bg-white dark:bg-[#1e1e1e] border-x border-b dark:border-gray-800 rounded-b-2xl p-2 space-y-1 shadow-sm">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={cn(
                "w-full flex items-center gap-3 p-3 rounded-xl text-left font-bold text-xs transition-all uppercase tracking-tight",
                activeTab === tab.id 
                  ? "bg-[#0A3D62] text-white shadow-md" 
                  : "text-gray-500 hover:bg-gray-50 dark:hover:bg-gray-800"
              )}
            >
              <tab.icon className={cn("w-4 h-4", activeTab === tab.id ? "text-white" : "text-gray-400")} />
              {tab.label}
            </button>
          ))}
        </nav>
      </aside>

      {/* CONTENT AREA */}
      <main className="flex-1">
        {activeTab === 'visual' && (
          <section className="bg-white dark:bg-[#1e1e1e] p-8 rounded-3xl shadow-sm border dark:border-gray-800 space-y-6">
            <div className="flex items-center justify-between border-b dark:border-gray-700 pb-4">
              <h3 className="font-black text-[#0A3D62] dark:text-blue-400 uppercase tracking-widest flex items-center gap-2">
                <Camera className="w-5 h-5" /> Identidad Visual
              </h3>
            </div>
            <div className="flex flex-col items-center gap-8 py-4">
              <div className="w-48 h-48 border-4 border-dashed border-gray-100 dark:border-gray-800 rounded-3xl flex items-center justify-center overflow-hidden bg-gray-50 dark:bg-gray-900 shadow-inner">
                {localConfig.logo ? (
                  <img src={localConfig.logo} alt="Logo Preview" className="max-w-full max-h-full object-contain p-4" />
                ) : (
                  <Camera className="w-12 h-12 text-gray-200" />
                )}
              </div>
              <div className="text-center space-y-4 max-w-sm">
                <p className="text-xs text-gray-400 font-medium leading-relaxed">
                  Sube el logotipo de tu negocio. Se mostrará en el encabezado y en las cotizaciones generadas. Formato recomendado: PNG o SVG transparente.
                </p>
                <div className="flex justify-center gap-3">
                  <label className="cursor-pointer bg-[#0A3D62] hover:bg-blue-800 text-white px-6 py-3 rounded-2xl text-xs font-black transition-all shadow-lg shadow-blue-900/20 active:scale-95">
                    SUBIR NUEVO LOGO
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (ev) => {
                            const base64 = ev.target?.result as string;
                            const updated = { ...localConfig, logo: base64 };
                            setLocalConfig(updated);
                            onSave(updated);
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                  {localConfig.logo && (
                    <button 
                      onClick={() => {
                        const updated = { ...localConfig, logo: undefined };
                        setLocalConfig(updated);
                        onSave(updated);
                      }}
                      className="bg-red-50 text-red-600 px-6 py-3 rounded-2xl text-xs font-black hover:bg-red-100 transition-all active:scale-95"
                    >
                      ELIMINAR
                    </button>
                  )}
                </div>
              </div>
            </div>
          </section>
        )}

        {activeTab === 'business' && (
          <section className="bg-white dark:bg-[#1e1e1e] p-8 rounded-3xl shadow-sm border dark:border-gray-800 space-y-6">
            <div className="flex items-center justify-between border-b dark:border-gray-700 pb-4">
              <h3 className="font-black text-[#0A3D62] dark:text-blue-400 uppercase tracking-widest flex items-center gap-2">
                <Mail className="w-5 h-5" /> Información del Negocio
              </h3>
            </div>
            <div className="grid grid-cols-1 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-tight">WhatsApp de Atención (Autopartes DL Torre)</label>
                <div className="relative">
                  <input 
                    type="tel" 
                    className="w-full p-4 rounded-2xl border-2 border-gray-50 dark:border-gray-800 dark:bg-gray-900 focus:border-[#0A3D62] transition-colors outline-none font-bold"
                    value={localConfig.businessPhone}
                    placeholder="Ej: 521234567890"
                    onChange={e => setLocalConfig({ ...localConfig, businessPhone: e.target.value })}
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] bg-green-100 text-green-700 px-2 py-1 rounded-lg font-bold">ACTIVO</div>
                </div>
              </div>
              <button 
                onClick={() => onSave(localConfig)}
                className="w-full bg-[#0A3D62] text-white py-4 rounded-2xl font-black text-sm shadow-xl shadow-blue-900/20 active:scale-[0.98] transition-all uppercase"
              >
                Guardar Configuración de Negocio
              </button>
            </div>
          </section>
        )}

        {activeTab === 'parts' && (
          <section className="bg-white dark:bg-[#1e1e1e] p-8 rounded-3xl shadow-sm border dark:border-gray-800 space-y-6">
            <div className="flex items-center justify-between border-b dark:border-gray-700 pb-4">
              <h3 className="font-black text-[#0A3D62] dark:text-blue-400 uppercase tracking-widest flex items-center gap-2">
                <Settings className="w-5 h-5" /> Botones de Piezas
              </h3>
              <button 
                onClick={() => {
                  const updated = [...localQuickParts, { nombre: "Nueva Pieza", lado: "N/A", posicion: "N/A", altura: "N/A" }];
                  setLocalQuickParts(updated);
                  onSaveQuickParts(updated);
                }}
                className="bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase hover:bg-blue-100 transition-colors"
              >
                + AGREGAR BOTÓN
              </button>
            </div>
            <div className="grid grid-cols-1 gap-4 max-h-[500px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-gray-100 pb-4">
              {localQuickParts.map((part, i) => (
                <div key={i} className="p-5 bg-gray-50 dark:bg-gray-900 rounded-2xl border dark:border-gray-800 flex flex-col sm:flex-row gap-4 items-center">
                  <div className="flex-1 grid grid-cols-2 lg:grid-cols-4 gap-2 w-full">
                    <div className="col-span-2 lg:col-span-1">
                      <label className="text-[8px] font-bold text-gray-400 uppercase">Nombre</label>
                      <input 
                        type="text" 
                        className="w-full p-2 text-xs rounded-xl border-2 border-transparent focus:border-[#0A3D62] outline-none font-bold"
                        value={part.nombre}
                        onChange={e => {
                          const updated = [...localQuickParts];
                          updated[i].nombre = e.target.value;
                          setLocalQuickParts(updated);
                          onSaveQuickParts(updated);
                        }}
                      />
                    </div>
                    <div>
                      <label className="text-[8px] font-bold text-gray-400 uppercase">Lado</label>
                      <select 
                        className="w-full p-2 text-xs rounded-xl border-2 border-transparent outline-none font-bold cursor-pointer"
                        value={part.lado}
                        onChange={e => {
                          const updated = [...localQuickParts];
                          updated[i].lado = e.target.value;
                          setLocalQuickParts(updated);
                          onSaveQuickParts(updated);
                        }}
                      >
                        <option value="N/A">N/A</option>
                        <option value="Derecho">Derecho</option>
                        <option value="Izquierdo">Izquierdo</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[8px] font-bold text-gray-400 uppercase">Posición</label>
                      <select 
                        className="w-full p-2 text-xs rounded-xl border-2 border-transparent outline-none font-bold cursor-pointer"
                        value={part.posicion}
                        onChange={e => {
                          const updated = [...localQuickParts];
                          updated[i].posicion = e.target.value;
                          setLocalQuickParts(updated);
                          onSaveQuickParts(updated);
                        }}
                      >
                        <option value="N/A">N/A</option>
                        <option value="Delantero">Delantero</option>
                        <option value="Trasero">Trasero</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[8px] font-bold text-gray-400 uppercase">Altura</label>
                      <select 
                        className="w-full p-2 text-xs rounded-xl border-2 border-transparent outline-none font-bold cursor-pointer"
                        value={part.altura}
                        onChange={e => {
                          const updated = [...localQuickParts];
                          updated[i].altura = e.target.value;
                          setLocalQuickParts(updated);
                          onSaveQuickParts(updated);
                        }}
                      >
                        <option value="N/A">N/A</option>
                        <option value="Superior">Superior</option>
                        <option value="Inferior">Inferior</option>
                      </select>
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                      const updated = localQuickParts.filter((_, idx) => idx !== i);
                      setLocalQuickParts(updated);
                      onSaveQuickParts(updated);
                    }}
                    className="p-3 text-red-500 hover:bg-red-50 rounded-xl transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </section>
        )}

        {activeTab === 'brands' && (
          <section className="bg-white dark:bg-[#1e1e1e] p-8 rounded-3xl shadow-sm border dark:border-gray-800 space-y-6">
            <div className="flex items-center justify-between border-b dark:border-gray-700 pb-4">
              <h3 className="font-black text-[#0A3D62] dark:text-blue-400 uppercase tracking-widest flex items-center gap-2">
                <Settings className="w-5 h-5" /> Marcas y Modelos
              </h3>
              <button 
                onClick={() => {
                  const marca = prompt('Nombre de la nueva marca (Nissan, Chevrolet, etc):');
                  if (marca) {
                    const updated = [...localCarBrands, { marca, modelos: [] }];
                    setLocalCarBrands(updated);
                    onSaveCarBrands(updated);
                  }
                }}
                className="bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase hover:bg-blue-100 transition-colors"
              >
                + NUEVA MARCA
              </button>
            </div>
            <div className="space-y-6 max-h-[500px] overflow-y-auto pr-2 scrollbar-thin pb-4">
              {localCarBrands.map((brand, i) => (
                <div key={i} className="p-6 bg-gray-50 dark:bg-gray-900 rounded-3xl border dark:border-gray-800 space-y-4 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-1 bg-[#0A3D62]/20 h-full group-hover:bg-[#0A3D62] transition-colors"></div>
                  <div className="flex justify-between items-center border-b dark:border-gray-800 pb-2">
                    <input 
                      type="text" 
                      className="font-black text-lg bg-transparent border-none focus:ring-0 outline-none uppercase text-[#0A3D62] dark:text-blue-400"
                      value={brand.marca}
                      onChange={e => {
                        const updated = [...localCarBrands];
                        updated[i].marca = e.target.value;
                        setLocalCarBrands(updated);
                        onSaveCarBrands(updated);
                      }}
                    />
                    <button 
                      onClick={() => {
                        const updated = localCarBrands.filter((_, idx) => idx !== i);
                        setLocalCarBrands(updated);
                        onSaveCarBrands(updated);
                      }}
                      className="text-red-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {brand.modelos.map((model, j) => (
                      <div key={j} className="flex items-center gap-2 bg-white dark:bg-gray-950 px-3 py-2 rounded-xl border dark:border-gray-800 shadow-sm transition-all hover:border-blue-200">
                        <span className="text-xs font-bold text-gray-600 dark:text-gray-400 uppercase">{model}</span>
                        <button 
                          onClick={() => {
                            const updated = [...localCarBrands];
                            updated[i].modelos = updated[i].modelos.filter((_, idx) => idx !== j);
                            setLocalCarBrands(updated);
                            onSaveCarBrands(updated);
                          }}
                          className="text-gray-300 hover:text-red-500 transition-colors"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                    <button 
                      onClick={() => {
                        const model = prompt(`Nuevo modelo para ${brand.marca}:`);
                        if (model) {
                          const updated = [...localCarBrands];
                          updated[i].modelos.push(model);
                          setLocalCarBrands(updated);
                          onSaveCarBrands(updated);
                        }
                      }}
                      className="px-4 py-2 border-2 border-dashed border-gray-200 dark:border-gray-800 rounded-xl text-[10px] font-black text-gray-400 hover:border-[#0A3D62] hover:text-[#0A3D62] transition-all bg-white dark:bg-transparent"
                    >
                      + AÑADIR MODELO
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {activeTab === 'data' && (
          <section className="bg-white dark:bg-[#1e1e1e] p-8 rounded-3xl shadow-sm border dark:border-gray-800 space-y-6">
            <div className="flex items-center justify-between border-b dark:border-gray-700 pb-4">
              <h3 className="font-black text-[#0A3D62] dark:text-blue-400 uppercase tracking-widest flex items-center gap-2">
                <FileJson className="w-5 h-5" /> Respaldo y Datos
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-6 bg-blue-50/50 dark:bg-blue-900/10 rounded-3xl border border-blue-100 dark:border-blue-900/30 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-blue-600 rounded-2xl">
                    <FileJson className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-black text-xs uppercase tracking-tight">Formato Universal (JSON)</h4>
                    <p className="text-[10px] text-gray-400 font-medium">Incluye piezas, marcas y TODAS las cotizaciones.</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={handleExport} className="flex-1 bg-blue-600 text-white p-3 rounded-2xl text-[10px] font-black uppercase hover:bg-blue-700 transition-all shadow-lg shadow-blue-900/20 active:scale-95">Exportar</button>
                  <label className="flex-1 bg-white dark:bg-gray-800 text-blue-600 p-3 rounded-2xl text-[10px] font-black uppercase text-center cursor-pointer border-2 border-blue-100 dark:border-blue-900/30 hover:bg-blue-50 transition-all active:scale-95">
                    Importar
                    <input type="file" className="hidden" accept=".json" onChange={handleImport} />
                  </label>
                </div>
              </div>

              <div className="p-6 bg-emerald-50/50 dark:bg-emerald-900/10 rounded-3xl border border-emerald-100 dark:border-emerald-900/30 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-emerald-600 rounded-2xl">
                    <FileSpreadsheet className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-black text-xs uppercase tracking-tight">Reporte Ventas (Excel/CSV)</h4>
                    <p className="text-[10px] text-gray-400 font-medium">Formato optimizado para tablas y contabilidad.</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={handleExportCSV} className="flex-1 bg-emerald-600 text-white p-3 rounded-2xl text-[10px] font-black uppercase hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-900/20 active:scale-95">Exportar CSV</button>
                  <label className="flex-1 bg-white dark:bg-gray-800 text-emerald-600 p-3 rounded-2xl text-[10px] font-black uppercase text-center cursor-pointer border-2 border-emerald-100 dark:border-emerald-900/30 hover:bg-emerald-50 transition-all active:scale-95">
                    Importar CSV
                    <input type="file" className="hidden" accept=".csv" onChange={handleImportCSV} />
                  </label>
                </div>
              </div>
            </div>

            <div className="space-y-3 pt-4">
              <button 
                onClick={handleEmailBackup}
                className="w-full p-5 bg-[#0A3D62] text-white rounded-2xl font-black text-sm shadow-xl hover:scale-[1.01] transition-all flex items-center justify-center gap-3 uppercase tracking-widest active:scale-95"
              >
                <Mail className="w-6 h-6" /> Enviar Respaldo por Email
              </button>
              <button 
                onClick={() => {
                  if (confirm('¿ELIMINAR TODO EL SISTEMA? Esta acción vaciará la base de datos de Autopartes DL Torre permanentemente.')) {
                    localStorage.clear();
                    indexedDB.deleteDatabase('autopartes-db');
                    window.location.reload();
                  }
                }}
                className="w-full p-4 border-2 border-red-100 text-red-500 rounded-2xl font-black text-[10px] uppercase hover:bg-red-50 transition-all flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" /> Reset de Fábrica (Peligro)
              </button>
            </div>
          </section>
        )}
      </main>
    </motion.div>
  );
}
