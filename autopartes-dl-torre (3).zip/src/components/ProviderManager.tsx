import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Plus, 
  Trash2, 
  Phone, 
  Search,
  ChevronLeft,
  UserPlus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Provider, getProviders, saveProvider, deleteProvider } from '../db';
import { cn } from '../utils';

interface ProviderManagerProps {
  onBack: () => void;
}

export default function ProviderManager({ onBack }: ProviderManagerProps) {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newProvider, setNewProvider] = useState({ name: '', phone: '' });

  useEffect(() => {
    loadProviders();
  }, []);

  const loadProviders = async () => {
    const loaded = await getProviders();
    setProviders(loaded);
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProvider.name) return;

    const provider: Provider = {
      id: crypto.randomUUID(),
      name: newProvider.name,
      phone: newProvider.phone
    };

    await saveProvider(provider);
    await loadProviders();
    setNewProvider({ name: '', phone: '' });
    setShowAddForm(false);
  };

  const handleDelete = async (id: string) => {
    if (confirm('¿Estás seguro de eliminar este proveedor?')) {
      await deleteProvider(id);
      await loadProviders();
    }
  };

  const filteredProviders = providers.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.phone.includes(search)
  ).sort((a, b) => a.name.localeCompare(b.name));

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto space-y-6"
    >
      <div className="flex justify-between items-center bg-white dark:bg-[#1e1e1e] p-6 rounded-2xl shadow-sm border dark:border-gray-800">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Users className="text-[#0A3D62] dark:text-blue-400" /> Directorio de Proveedores
            </h2>
            <p className="text-sm text-gray-500">Gestiona tus contactos para cotizaciones</p>
          </div>
        </div>
        <button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-[#0A3D62] text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:scale-105 transition-all shadow-lg text-sm uppercase"
        >
          <UserPlus className="w-5 h-5" /> {showAddForm ? 'CANCELAR' : 'NUEVO PROVEEDOR'}
        </button>
      </div>

      <AnimatePresence>
        {showAddForm && (
          <motion.form 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            onSubmit={handleAdd}
            className="bg-white dark:bg-[#1e1e1e] p-6 rounded-2xl shadow-sm border dark:border-gray-800 space-y-4 overflow-hidden"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">Nombre del Proveedor</label>
                <input 
                  autoFocus
                  type="text" 
                  className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 outline-none focus:ring-2 focus:ring-blue-500 transition-all font-bold"
                  placeholder="Ej: Refaccionaria García"
                  value={newProvider.name}
                  onChange={e => setNewProvider({ ...newProvider, name: e.target.value })}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-gray-400 uppercase">WhatsApp (Opcional)</label>
                <input 
                  type="tel" 
                  className="w-full p-3 rounded-xl border dark:bg-gray-800 dark:border-gray-700 outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                  placeholder="Ej: 3312345678"
                  value={newProvider.phone}
                  onChange={e => setNewProvider({ ...newProvider, phone: e.target.value })}
                />
              </div>
            </div>
            <button 
              type="submit"
              className="w-full bg-emerald-500 text-white py-3 rounded-xl font-bold shadow-lg hover:scale-[1.01] transition-all flex items-center justify-center gap-2 uppercase"
            >
              <Plus className="w-5 h-5" /> Guardar Proveedor
            </button>
          </motion.form>
        )}
      </AnimatePresence>

      <div className="bg-white dark:bg-[#1e1e1e] rounded-2xl shadow-sm border dark:border-gray-800 overflow-hidden">
        <div className="p-4 border-b dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/50">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input 
              type="text" 
              placeholder="Buscar por nombre o teléfono..."
              className="w-full pl-10 pr-4 py-3 bg-white dark:bg-gray-900 border dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-[#0A3D62] transition-all"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-gray-100 dark:bg-gray-800">
                <th className="p-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-wider">Nombre</th>
                <th className="p-4 text-left text-[10px] font-bold text-gray-400 uppercase tracking-wider">WhatsApp</th>
                <th className="p-4 text-right text-[10px] font-bold text-gray-400 uppercase tracking-wider">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y dark:divide-gray-700">
              {filteredProviders.length > 0 ? (
                filteredProviders.map((provider) => (
                  <tr key={provider.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                    <td className="p-4 font-bold text-gray-700 dark:text-gray-200">{provider.name}</td>
                    <td className="p-4">
                      {provider.phone ? (
                        <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-medium">
                          <Phone className="w-4 h-4" />
                          {provider.phone}
                        </div>
                      ) : (
                        <span className="text-xs text-gray-400 italic">Sin teléfono</span>
                      )}
                    </td>
                    <td className="p-4 text-right space-x-2">
                      <button 
                        onClick={() => handleDelete(provider.id)}
                        className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
                        title="Eliminar"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={3} className="p-20 text-center text-gray-400 italic">
                    {search ? 'No se encontraron proveedores que coincidan con la búsqueda.' : 'No hay proveedores registrados.'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
